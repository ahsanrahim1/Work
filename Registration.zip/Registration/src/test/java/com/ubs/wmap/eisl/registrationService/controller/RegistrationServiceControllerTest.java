package com.ubs.wmap.eisl.registrationService.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import com.ubs.wmap.eisl.registrationService.exception.EsilTokenNotValidException;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.model.RoleRequestVO;
import com.ubs.wmap.eisl.registrationService.model.RowReferenceRequestVO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;

import java.util.HashSet;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;

/*@Slf4j
@SuppressWarnings("deprecation")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)*/
@Slf4j
@SuppressWarnings("deprecation")
@RunWith(MockitoJUnitRunner.class)
public class RegistrationServiceControllerTest {

	@Mock
	RegistrationServiceImpl registrationService;

	@InjectMocks
    RegistrationServiceController regServiceController;


        @Test
        public void registrationGetTest() throws Exception{
            ResponseSO testResponse = new ResponseSO();
            ResponseEntity<ResponseSO> responseEntity = new ResponseEntity<>(testResponse,HttpStatus.OK);
            Mockito.lenient().when(registrationService.isTokenValid(Mockito.anyString())).thenReturn(true);
            Mockito.when(registrationService.getRegistration(ArgumentMatchers.anyString())).thenReturn(testResponse);
            ResponseEntity<ResponseSO> expected = regServiceController.getRegistry("testBasic", "testEisl");
            assertEquals("Registration found",responseEntity.getBody(),expected.getBody());
        }
        
        @Test(expected = EsilTokenNotValidException.class)
        public void registrationGetEislNotValid() throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException{
           regServiceController.getRegistry("testBasic", "testEisl");
        }
        
        @Test(expected = InvalidDataException.class)
        public void registrationGetInvalidData() throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException{
            Mockito.lenient().when(registrationService.isTokenValid(Mockito.anyString())).thenReturn(true);
            //Mockito.when(regServiceController.getRegistry(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenThrow(InvalidDataException.class);
            Mockito.when(registrationService.getRegistration(ArgumentMatchers.anyString())).thenThrow(InvalidDataException.class);
            regServiceController.getRegistry("testBasic", "testEisl");
        }
        
        @Test
        public void resgistrationPostTest() throws Exception{
            PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            ResponseEntity<RegistrationSO> responseEntity =new ResponseEntity(testRegistration, HttpStatus.CREATED);   
            Mockito.lenient().when(registrationService.isTokenValid(Mockito.anyString())).thenReturn(true);
            //Mockito.when(regServiceController.addRegistry(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenReturn(responseEntity);
            Mockito.when(registrationService.postRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenReturn(testRegistration);
            ResponseEntity<RegistrationSO> expectedResponse = regServiceController.addRegistry("basic", eislToken, testPayload);
            assertEquals("Success", responseEntity.getBody(), expectedResponse.getBody());
            assertEquals("created",HttpStatus.OK,expectedResponse.getStatusCode());
        }
        
        @Test(expected = EsilTokenNotValidException.class)
        public void registrationPostEislNotValid() throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException{
            PayloadSO payload = new PayloadSO();
            //Mockito.lenient().when(registrationService.validateToken(Mockito.anyString(), Mockito.anyString())).thenReturn(false);
            //Mockito.when(regServiceController.addRegistry(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenThrow(EsilTokenNotValidException.class);
            regServiceController.addRegistry("testBaisc", "testEisl", payload);
        }
        
        @Test(expected = InvalidDataException.class)
        public void registrationPostInvalidData() throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException{
            PayloadSO payload = new PayloadSO();
            Mockito.lenient().when(registrationService.isTokenValid(Mockito.anyString())).thenReturn(true);
            //Mockito.when(regServiceController.addRegistry(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenThrow(InvalidDataException.class);
            Mockito.when(registrationService.postRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenThrow(InvalidDataException.class);
            regServiceController.addRegistry("testBaisc", "testEisl", payload);
        }
        
        @Test
        public void resgistrationPutTest() throws Exception{
            PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            ResponseEntity<RegistrationSO> responseEntity =new ResponseEntity<RegistrationSO>(testRegistration, HttpStatus.OK);   
            Mockito.lenient().when(registrationService.isTokenValid(Mockito.anyString())).thenReturn(true);
            //Mockito.when(regServiceController.updateRegistry(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenReturn(responseEntity);
            Mockito.when(registrationService.putRegistration(Mockito.anyString(), Mockito.any(PayloadSO.class))).thenReturn(testRegistration);
            ResponseEntity<RegistrationSO> expectedResponse = regServiceController.updateRegistry("basic", eislToken, testPayload);
           assertEquals("Success", responseEntity.getBody(), expectedResponse.getBody());
            assertEquals("created",HttpStatus.OK,expectedResponse.getStatusCode());        
        }
        
        @Test(expected = EsilTokenNotValidException.class)
        public void registrationPutEislNotValid() throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException{
            PayloadSO payload = new PayloadSO();
            regServiceController.updateRegistry("testBaisc", "testEisl", payload);
        }
        
         @Test(expected = InvalidDataException.class)
        public void registrationPutInvalidData() throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException{
            PayloadSO payload = new PayloadSO();
            Mockito.lenient().when(registrationService.isTokenValid(Mockito.anyString())).thenReturn(true);
            //Mockito.when(regServiceController.updateRegistry(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenThrow(InvalidDataException.class);
            Mockito.when(registrationService.putRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenThrow(InvalidDataException.class);
            regServiceController.updateRegistry("testBaisc", "testEisl", payload);
        }
        
        @Test
        public void registrationDeleteTest()throws Exception{
           Mockito.lenient().when(registrationService.isTokenValid(Mockito.anyString())).thenReturn(true);
           ResponseSO testResponse = new ResponseSO();
           Mockito.lenient().when(registrationService.deleteRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(testResponse);
           ResponseEntity<Object> expectedResponse = regServiceController.deleteRegistry("testBasic", "testEisl");
           assertEquals("Registration Deleted",HttpStatus.OK,expectedResponse.getStatusCode());
        }


}
