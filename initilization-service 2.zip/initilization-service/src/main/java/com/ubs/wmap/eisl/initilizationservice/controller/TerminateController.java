
package com.ubs.wmap.eisl.initilizationservice.controller;

import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.service.InitilizationServiceImpl;
import javax.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author ahsanrahim
 */
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
public class TerminateController {

    @Qualifier("terminateService")
    private final InitilizationServiceImpl initializationService;


    @DeleteMapping("/eisl/intialization/v1/registrations")
    public ResponseEntity<?> terminateInitilization(@NotBlank @RequestHeader (name = "basicToken") final String basicToken,
            @NotBlank @RequestParam("eislToken") final String eislToken ) throws InvalidEislTokenException
    {
        try {
            log.debug("Entering Terminate Sequence");
            boolean isValid = initializationService.validateEislToken(eislToken);
            initializationService.deleteRegistration(basicToken, eislToken);
            return ResponseEntity.ok().build();
        } catch (InvalidEislTokenException ex) {
            log.error("Eisl Token Invalid");
            throw new InvalidEislTokenException("EislTokenNotValid");
        }
    }
}
