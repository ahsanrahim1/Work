
package com.ubs.wmap.eisl.initilizationservice.models;

import lombok.Data;

/**
 *
 * @author ahsanrahim
 */
@Data
public class Payload {
    String userName;
    String company;
    
}
