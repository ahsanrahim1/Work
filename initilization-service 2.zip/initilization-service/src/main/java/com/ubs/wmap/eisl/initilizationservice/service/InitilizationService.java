/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ubs.wmap.eisl.initilizationservice.service;

import com.ubs.wmap.eisl.initilizationservice.models.Payload;

/**
 *
 * @author ahsanrahim
 */
public interface InitilizationService {
    void putRegistration(String basicToken,String eislToken, Payload payload);
    void deleteRegistration(String basicToken,String eislToken);
    void postRegistration(String basicToken,String eislToken, Payload payload);
    
}
