
package com.ubs.wmap.eisl.registrationService.service;

import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.model.RoleRequestVO;
import com.ubs.wmap.eisl.registrationService.model.RowReferenceRequestVO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.core.token.TokenService;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author ahsanrahim
 */
@Slf4j
@SuppressWarnings("deprecation")
@RunWith(MockitoJUnitRunner.class)
public class ResgistrationServiceTest {
    
    @Mock
    RestTemplate restTemplate;

    @Mock
    TokenService tokenService;
    
    @Mock
    RegistrationServiceImpl registrationService;
    
    @Test
    public void getRegistryTest() throws Exception{
        ResponseSO testResponse = new ResponseSO();
        Map<String,Object> test = new HashMap<>();
        Map<String,Object> test2 = new HashMap<>();
        Map<String,Object> test3 = new HashMap<>();
        System.out.println(test.toString());
        testResponse.setResponse(test);
        System.out.println(testResponse.toString());
        Mockito.when(registrationService.getRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(testResponse);
        ResponseSO expected = registrationService.getRegistration("test", "test");
         assertEquals("Success",testResponse,expected);
    }
    
    
    @Test
    public void postRegistrationTest() throws InvalidDataException, DataNotFoundException {
        PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            Mockito.when(registrationService.postRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenReturn(testRegistration);
            RegistrationSO result = registrationService.postRegistration("testBasic", eislToken, testPayload);
            assertEquals("Registration posted",testRegistration,result);
    }
    
    @Test(expected = InvalidDataException.class)
    public void postRegistrationInvalidDataTest() throws InvalidDataException, DataNotFoundException {
            PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            Mockito.when(registrationService.postRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenThrow(InvalidDataException.class);
            RegistrationSO result = registrationService.postRegistration("testBasic", eislToken, testPayload);
    }
    
    @Test
    public void putRegistrationTest() throws InvalidDataException, DataNotFoundException {
            PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            Mockito.when(registrationService.putRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenReturn(testRegistration);
            RegistrationSO result = registrationService.putRegistration("testBasic", eislToken, testPayload);
            assertEquals("Registration posted",testRegistration,result);
    }
    
    @Test(expected = InvalidDataException.class)
    public void putRegistrationInvalidDataTest() throws InvalidDataException, DataNotFoundException {
            PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            Mockito.when(registrationService.putRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.any(PayloadSO.class))).thenThrow(InvalidDataException.class);
            RegistrationSO result = registrationService.putRegistration("testBasic", eislToken, testPayload);
    }
    
    @Test
    public void deleteRegistrationTest(){
        ResponseSO testResponse = new ResponseSO();
        Mockito.when(registrationService.deleteRegistration(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(testResponse);
        ResponseSO result = registrationService.deleteRegistration("/test/", "testBasic", "testEisl");
        assertEquals("Registration deleted",testResponse,result);
    }
    
    
    @Test
    public void getEventTest() throws DataNotFoundException{
       String eventResponse = "test Event response";
       Mockito.when(registrationService.getEventsResponse(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(eventResponse);
       String result = registrationService.getEventsResponse("/test/", "testBasic", "testEisl");
       assertEquals("Exception data found",eventResponse,result);
    }
    
    @Test(expected = DataNotFoundException.class)
    public void getEventDataNotFoundTest() throws DataNotFoundException{
       String eventResponse = "test Event response";
       Mockito.when(registrationService.getEventsResponse(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenThrow(DataNotFoundException.class);
       String result = registrationService.getEventsResponse("/test/", "testBasic", "testEisl");
    }
    
    @Test
    public void getExceptionTest() throws DataNotFoundException{
       String exceptionResponse = "test Exception response";
       Mockito.when(registrationService.getExceptionsResponse(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(exceptionResponse);
       String result = registrationService.getExceptionsResponse("/test/", "testEisl", "testExceptionServiceId", "TestBasic");
       assertEquals("Exception data found",exceptionResponse,result);
    }
    
    @Test(expected = DataNotFoundException.class)
    public void getExceptionDataNotFoundTest() throws DataNotFoundException{
       String exceptionResponse = "test Exception response";
       Mockito.when(registrationService.getExceptionsResponse(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenThrow(DataNotFoundException.class);
       String result = registrationService.getExceptionsResponse("/test/", "testEisl", "testExceptionServiceId", "TestBasic");
    }
    
    @Test
    public void getDataTest() throws DataNotFoundException{
       String dataResponse = "test data response";
       Mockito.when(registrationService.getDataResponse(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(dataResponse);
       String result = registrationService.getDataResponse("/test/", "testEisl", "testDataServiceId", "TestBasic");
       assertEquals("Exception data found",dataResponse,result);
    }
    @Test
    public void getRegistryResponseTest() throws DataNotFoundException{
        PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            Mockito.when(registrationService.getRegistryResponse(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(testRegistration);
            RegistrationSO result = registrationService.getRegistryResponse("/test/", eislToken, "testBasic");
            assertEquals("Registration found", testRegistration,result);      
    }
    
    @Test
    public void postRegistryResponseTest() throws DataNotFoundException{
            PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            Mockito.when(registrationService.postRegistryResponse(ArgumentMatchers.anyString(), ArgumentMatchers.any(RegistrationSO.class), ArgumentMatchers.anyString())).thenReturn(testRegistration);
            RegistrationSO result = registrationService.postRegistryResponse("/test/", testRegistration, "testBasic");
            assertEquals("Registration saved", testRegistration,result); 
    }
    
//    @Test(expected = DataNotFoundException.class)
//    public void postRegistryResponseDataNotFoundTest() throws DataNotFoundException{
//            PayloadSO testPayload = new PayloadSO();
//            testPayload.setCompany("testCompany");
//            testPayload.setUserId("testUserId");
//            RoleRequestVO testRole = new RoleRequestVO();
//            testRole.setConsume("testConsume");
//            testRole.setPublish("setPublish");
//            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
//            testColRef.setName("test column name");
//            testColRef.setType("test column type");
//            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
//            testColumnRefSet.add(testColRef);
//            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
//            testRowRef.setName("test row name");
//            testRowRef.setType("test row type");
//            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
//            testRowRefSet.add(testRowRef);
//            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
//            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
//            Mockito.when(registrationService.postRegistryResponse(ArgumentMatchers.anyString(), ArgumentMatchers.any(RegistrationSO.class), ArgumentMatchers.anyString())).thenThrow(DataNotFoundException.class);
//            RegistrationSO result = registrationService.postRegistryResponse("/test/", testRegistration, "testBasic"); 
//    }
    
    @Test
    public void putRegistryResponseTest() throws DataNotFoundException, InvalidDataException{
            PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            Mockito.when(registrationService.putRegistryResponse(ArgumentMatchers.anyString(), ArgumentMatchers.any(RegistrationSO.class))).thenReturn(testRegistration);
            RegistrationSO result = registrationService.putRegistryResponse("/test/", testRegistration);
            assertEquals("Registration saved", testRegistration,result); 
    }
    
//    @Test(expected = DataNotFoundException.class)
//    public void putRegistryResponseDataNotFoundTest() throws DataNotFoundException, InvalidDataException{
//            PayloadSO testPayload = new PayloadSO();
//            testPayload.setCompany("testCompany");
//            testPayload.setUserId("testUserId");
//            RoleRequestVO testRole = new RoleRequestVO();
//            testRole.setConsume("testConsume");
//            testRole.setPublish("setPublish");
//            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
//            testColRef.setName("test column name");
//            testColRef.setType("test column type");
//            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
//            testColumnRefSet.add(testColRef);
//            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
//            testRowRef.setName("test row name");
//            testRowRef.setType("test row type");
//            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
//            testRowRefSet.add(testRowRef);
//            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
//            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
//            Mockito.when(registrationService.putRegistryResponse(ArgumentMatchers.anyString(), ArgumentMatchers.any(RegistrationSO.class))).thenThrow(DataNotFoundException.class);
//            RegistrationSO result = registrationService.putRegistryResponse("/test/", testRegistration); 
//    }
    
    @Test(expected = InvalidDataException.class)
    public void putRegistryResponseInvalidDataTest() throws DataNotFoundException, InvalidDataException{
            PayloadSO testPayload = new PayloadSO();
            testPayload.setCompany("testCompany");
            testPayload.setUserId("testUserId");
            RoleRequestVO testRole = new RoleRequestVO();
            testRole.setConsume("testConsume");
            testRole.setPublish("setPublish");
            ColumnReferenceRequestVO testColRef = new ColumnReferenceRequestVO();
            testColRef.setName("test column name");
            testColRef.setType("test column type");
            Set<ColumnReferenceRequestVO> testColumnRefSet = new HashSet<>();
            testColumnRefSet.add(testColRef);
            RowReferenceRequestVO testRowRef = new RowReferenceRequestVO();
            testRowRef.setName("test row name");
            testRowRef.setType("test row type");
            Set<RowReferenceRequestVO> testRowRefSet = new HashSet<>();
            testRowRefSet.add(testRowRef);
            String eislToken = "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs";
            RegistrationSO testRegistration = RegistrationSO.builder().userId(testPayload.getUserId()).company(testPayload.getCompany()).eislToken(eislToken).dataEntitlement("testDataEntitlement").role(testRole).serviceId("testServiceId").userName("testUserName").columnReferences(testColumnRefSet).rowReferences(testRowRefSet).serviceId("testServiceId").build();
            Mockito.when(registrationService.putRegistryResponse(ArgumentMatchers.anyString(), ArgumentMatchers.any(RegistrationSO.class))).thenThrow(InvalidDataException.class);
            RegistrationSO result = registrationService.putRegistryResponse("/test/", testRegistration); 
    }

    
}
