package com.ubs.wmap.eisl.registrationService.exception;

public class DataNotFoundException extends Exception{
   
	private static final long serialVersionUID = -2005456296722980632L;

	public DataNotFoundException(String message) {
        super(message);
    }
}
