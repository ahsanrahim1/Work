package com.ubs.wmap.eisl.registrationService.registrationservice.service;

import java.util.Map;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.ubs.wmap.eisl.inhousekeepinglibrary.service.TokenService;
import com.ubs.wmap.eisl.registrationService.registrationservice.DTO.ResponseDTO;


@Service
public class RegistrationService {
	
	

	  
	  @Autowired
	  private RestTemplate restTemplate;
	  private TokenService tokenService;

	

    public boolean validateToken(String basicToken, String eislToken, Map<String,String> claims) {
    	 boolean isValid = false;
    	try {
          isValid = tokenService.isEislTokenValid(eislToken);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return isValid;
        
    }
    
    public String  getResponse(String baseUrl,String basicToken,String eislToken) {
   
        final String url = String.format("/eisl/%s", baseUrl);
       
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("basicToken",basicToken )
                .queryParam("eislToken", eislToken);
        
        final ResponseEntity<String> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, null,
                        new ParameterizedTypeReference<String>() {});
        return responseDto.getBody();
      }
    
    public String deleteRegistration( String baseUrl, String basicToken,String eislToken)
    {
    	final String url = String.format("/eisl/%s", baseUrl);
    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("basicToken",basicToken )
                .queryParam("eislToken", eislToken);
    	
    	final ResponseEntity<String> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE, null,
                new ParameterizedTypeReference<String>() {});
    	return responseDto.getBody();
    }

	public ResponseDTO getRegistration(@NotBlank String basicToken, @NotBlank String eislToken) {

		ResponseDTO responseDTO = new ResponseDTO();
		
		String eventsResponse = getResponse("events/v1/events", null, null);
		responseDTO.setRespString(eventsResponse);
		
		String dataResponse = getResponse("data/v1/data", null, null);
		responseDTO.setRespString(dataResponse);
		
		String exceptionResponse = getResponse("exception/v1/exceptions", null, null);
		responseDTO.setRespString(exceptionResponse);
		
		return responseDTO;
	}
}
