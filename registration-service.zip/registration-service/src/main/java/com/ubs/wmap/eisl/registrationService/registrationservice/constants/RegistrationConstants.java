package com.ubs.wmap.eisl.registrationService.registrationservice.constants;

public class RegistrationConstants {
   
	public static final String REGISTRATION_END_POINT = "/eisl/registrations/v1/registrations";
	public static final String EVENTS_END_POINT = "events/v1/events";
	public static final String DATA_END_POINT = "data/v1/data";
	public static final String EXCEPTIONS_END_POINT = "exception/v1/exceptions";

	
	
}
