package com.ubs.wmap.eisl.registrationService.registrationservice.exception;

@SuppressWarnings("serial")
public class InvalidDataException extends RuntimeException {

	public InvalidDataException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidDataException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
   
}
