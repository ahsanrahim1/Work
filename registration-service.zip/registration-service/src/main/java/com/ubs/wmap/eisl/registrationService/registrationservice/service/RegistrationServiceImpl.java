package com.ubs.wmap.eisl.registrationService.registrationservice.service;

import static com.ubs.wmap.eisl.registrationService.registrationservice.constants.RegistrationConstants.DATA_END_POINT;
import static com.ubs.wmap.eisl.registrationService.registrationservice.constants.RegistrationConstants.EVENTS_END_POINT;
import static com.ubs.wmap.eisl.registrationService.registrationservice.constants.RegistrationConstants.EXCEPTIONS_END_POINT;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.ubs.wmap.eisl.inhousekeepinglibrary.service.TokenService;
import com.ubs.wmap.eisl.registrationService.registrationservice.DTO.ResponseDTO;
import com.ubs.wmap.eisl.registrationService.registrationservice.exception.InvalidDataException;


@Service
public class RegistrationServiceImpl {
	
	

	  
	  @Autowired
	  private RestTemplate restTemplate;
	  private TokenService tokenService;

	

    public boolean validateToken(String basicToken, String eislToken, Map<String,String> claims) {
    	 boolean isValid = false;
    	try {
          isValid = tokenService.isEislTokenValid(eislToken);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return isValid;
        
    }
    
    public HashMap<String,String>  getEventsResponse(String baseUrl,String firstParam,String stringParam) {
   
        final String url = String.format("/eisl/%s", baseUrl);
       
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("basicToken",firstParam )
                .queryParam("eislToken", stringParam);
        
        return responseGetter(builder);
      }
    
    public HashMap<String,String>  getDataResponse(String baseUrl,String firstParam,String stringParam) {
    	   
        final String url = String.format("/eisl/%s", baseUrl);
       
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken",firstParam )
                .queryParam("dataServiceId", stringParam);
        
        return responseGetter(builder);
      }
    
    public HashMap<String,String>  getExceptionsResponse(String baseUrl,String firstParam,String stringParam) {
    	   
        final String url = String.format("/eisl/%s", baseUrl);
       
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken",firstParam )
                .queryParam("exceptionServiceId", stringParam);
        
        return responseGetter(builder);
      }

	private HashMap<String, String> responseGetter(UriComponentsBuilder builder) {
		final ResponseEntity<HashMap<String,String>> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, null,
                        new ParameterizedTypeReference<HashMap<String,String>>() {});
        return responseDto.getBody();
	}
    
    public String deleteRegistration( String baseUrl, String basicToken,String eislToken)
    {
    	final String url = String.format("/eisl/%s", baseUrl);
    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("basicToken",basicToken )
                .queryParam("eislToken", eislToken);
    	
    	final ResponseEntity<String> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE, null,
                new ParameterizedTypeReference<String>() {});
    	return responseDto.getBody();
    }

	public ResponseDTO getRegistration(@NotBlank String basicToken, @NotBlank String eislToken) {

		ResponseDTO responseDTO = new ResponseDTO();
		HashMap<String,String> eventsResponse = getEventsResponse(EVENTS_END_POINT, basicToken, eislToken);
		HashMap<String,String> dataResponse = getDataResponse(DATA_END_POINT, eislToken, eventsResponse.get("dataServiceId"));
		HashMap<String,String> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, eislToken, eventsResponse.get("exceptionServiceId"));
		if(eventsResponse == null || dataResponse == null || exceptionResponse == null) {
			throw new InvalidDataException();
		}
		return responseDTO;
	}
}
