package com.ubs.wmap.eisl.registrationService.registrationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.ubs.wmap.inhousekeepinglibrary","com.ubs.wmap.eisl.registrationService.registrationservice","com.ubs.wmap.eisl.registrationService.registrationservice.service"})
public class RegistrationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationServiceApplication.class, args);
	}

}
