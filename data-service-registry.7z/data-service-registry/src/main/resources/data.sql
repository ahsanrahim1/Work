insert into DATA_REFERENCE (Data_reference_id, Data_service_id, Data_in_topic)
values (1, 'service1', 'topictest');

insert into DATA_OUT_REFERENCE (Data_out_reference_id, Protocol_name, Data_type, topic,  Data_reference_id)
values (1, 'protocolTest1','rest', 'topicTest3', 1);

insert into DATA_FILTER_REFERENCE (Filter_reference_id, name, options, Data_out_reference_id)
values (1,'filtertest1','filteroption1', 1);