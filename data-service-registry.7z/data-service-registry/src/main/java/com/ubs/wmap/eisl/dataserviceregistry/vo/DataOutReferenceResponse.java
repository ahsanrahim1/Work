package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class DataOutReferenceResponse implements Serializable {

	private static final long serialVersionUID = 8023385196692316336L;
	private Integer dataOutReferenceId;
	private String protocolName;
	private String dataType;
	private String topic;
	@EqualsAndHashCode.Exclude
	private DataFilterResponse dataFilterReference;
}
