
package com.ubs.wmap.eisl.housekeeping.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "Exception during events service")
public class InvalidEislTokenException extends Exception {

    
    public InvalidEislTokenException() {
        super();
    }

   
    public InvalidEislTokenException(String msg) {
        super(msg);
    }
    
    public InvalidEislTokenException(String msg, Throwable cause){
      super(msg,cause);
    }
}
