
package com.ubs.wmap.eisl.housekeeping.controller;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.exception.InvalidEislTokenException;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotBlank;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RequestMapping( produces = "application/json")
public class HouseKeepingSecurityController {

	
	private final TokenService tokenService;

	@Value("${service.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
        
        @Value("${service.message.EISL_TOKEN_NOT_VALID_MSG}")
        private String EISL_NOT_VALID_MSG;
        
        @Value("S{service.custome.eisl_claims_service_id}")
        private String eislClaimsServiceId;

	@GetMapping("/unwrap")
	public ResponseEntity<Map<String,Object>> unWrapEislToken(@NotBlank @RequestParam("token") final String eislToken) throws Exception{
                if(!servicePreconditions(eislToken).containsKey(eislClaimsServiceId)){
                   return (ResponseEntity<Map<String,Object>>) ResponseEntity.status(403);
                }
		Map<String, Object> mapFromIoJsonwebtokenClaims; 
		try {
			mapFromIoJsonwebtokenClaims  = servicePreconditions(eislToken);
		}catch (Exception e) {
			throw new Exception(INTERNAL_SERVER_ERROR_MSG);
		}
		return ResponseEntity.ok()
				.body(mapFromIoJsonwebtokenClaims);

	}
	
	public Map<String,Object> servicePreconditions(String eislToken) throws InvalidEislTokenException{
		Map<String,Object> eislClaims;
                try{
		eislClaims = tokenService.init(eislToken);
                }catch(Exception ex) {
                 throw new InvalidEislTokenException(EISL_NOT_VALID_MSG);
                }
		
                return eislClaims;
	}
	
}
