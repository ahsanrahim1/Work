
package com.ubs.wmap.eisl.housekeeping.controller;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.housekeeping.exception.BadRequestException;
import com.ubs.wmap.eisl.housekeeping.exception.InvalidEISLTokenException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotBlank;
import java.util.Map;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RequestMapping( produces = "application/json")
public class HouseKeepingSecurityController {

	
	private final TokenService tokenService;

	@Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;

	@Value("${app.message.EISL_INVALID_TOKEN_MSG}")
	private String EISL_INVALID_TOKEN_MSG;

	@Value("${app.message.TOKEN_EMPTY_MSG}")
	private String TOKEN_EMPTY_MSG;

	@Value("${app.custom.eisl_attribute_name}")
	private String eislClaimsAttribute;

	@GetMapping("/unwrap")
	public ResponseEntity<Map<String,Object>> unWrapEislToken(@NotBlank @RequestParam("token") final String token) throws Exception{

	    log.info(tokenService.createEILSToken("utmis", "acc", "adfmin"));
		if (StringUtils.isEmpty(token)) {
			throw new BadRequestException(TOKEN_EMPTY_MSG);
		}

		Map<String, Object> claims = servicePreconditions(token);
		if (!claims.containsKey(eislClaimsAttribute)) {
			return (ResponseEntity<Map<String, Object>>) ResponseEntity.status(403);
		}


		return ResponseEntity.ok()
				.body(claims);

	}

    public Map<String, Object> servicePreconditions(String eislToken) throws InvalidEISLTokenException, BadRequestException {
        Map<String, Object> eislClaims;
        try {
            eislClaims = tokenService.init(eislToken);
        } catch (TokenExpireException | TokenUnwrapException ex) {
            throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
        } catch (RuntimeException rx) {
            log.error(rx.getMessage());
            throw new BadRequestException(INTERNAL_SERVER_ERROR_MSG);
        }

        return  eislClaims;
    }
	
}
