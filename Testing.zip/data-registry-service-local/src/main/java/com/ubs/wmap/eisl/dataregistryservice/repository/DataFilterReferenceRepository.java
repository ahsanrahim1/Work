package com.ubs.wmap.eisl.dataregistryservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.dataregistryservice.model.DataFilter;

@Repository
public interface DataFilterReferenceRepository extends JpaRepository<DataFilter, Integer> {

}
