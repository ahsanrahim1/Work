package com.ubs.wmap.eisl.dataregistryservice.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class ProtocolsResponse implements Serializable{
	
	private static final long serialVersionUID = -643575652977493604L;
	
	private Integer ProtocolsId;
	
	private String name;
	
	private String details;
}
