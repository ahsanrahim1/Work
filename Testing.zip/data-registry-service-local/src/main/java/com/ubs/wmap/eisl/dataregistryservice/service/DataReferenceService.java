package com.ubs.wmap.eisl.dataregistryservice.service;

import com.ubs.wmap.eisl.dataregistryservice.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataReferenceResponse;

public interface DataReferenceService {

	/**
	 * Method to get the Data reference details from db
	 * @param dataReferenceRequest
	 * 			Mandatory parameter which contains serviceId
	 * @return DataReferenceResponse
	 * 			Data Reference details and its child elements,
	 * 			null if not found
	 * @throws DataReferenceException
	 */
	DataReferenceResponse getDataReference(DataReferenceRequest dataReferenceRequest)
			throws DataReferenceException;



	/**
	 * Method to save data reference to db
	 * @param dataReferencerequest
	 * 			Mandatory parameter which contains Data reference
	 * 			details and its associated entities.
	 * @return DataReferenceResponse
	 * 			Data Reference details and its child elements,
	 * 			null if data not saved to database
	 * @throws DataReferenceException
	 */
	DataReferenceResponse saveDataReference(DataReferenceRequest dataReferencerequest)
			throws DataReferenceException;
}
