package com.ubs.wmap.eisl.dataregistryservice.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class DataFilterResponse implements Serializable{

	private static final long serialVersionUID = 228694173931964139L;
	private Integer filterId;
	private String name;
	private String options;
}
