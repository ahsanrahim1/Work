package com.ubs.wmap.eisl.dataregistryservice.repository;

import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.dataregistryservice.model.DataAccessModel;

@Repository
public interface DataModelRepository extends CustomRepository<DataAccessModel, Integer>{

}
