package com.ubs.wmap.eisl.dataregistryservice.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class DataAccessModelResponse implements Serializable{
	
	private static final long serialVersionUID = 6520595970413107772L;
	private Integer dataAccessModelId;
	private String modelName;
}
