insert into DATA_REFERENCE (Data_reference_id, Data_service_id) values (101, 101);

insert into DATA_REFERENCE (Data_reference_id, Data_service_id) values (102, 102);


insert into FILTER (Filter_id, Name, Options, Data_reference_id) values (1, 'filter1', 'opt1', 101);

insert into FILTER (Filter_id, Name, Options, Data_reference_id) values (2, 'filter2', 'opt2', 102);


insert into PROTOCOLS (PROTOCOLS_ID, DETAILS, NAME, DATA_REFERENCE_ID) values (1, 'Data Hub', 'EVENT_FOO', 101);

insert into PROTOCOLS (PROTOCOLS_ID, DETAILS, NAME, DATA_REFERENCE_ID) values (2, 'Data Hub', 'EVENT_BAR', 102);



insert into DATA_ACCESS_MODEL (DATA_ACCESS_MODEL_ID, MODEL_NAME, DATA_REFERENCE_ID) values (1, 'Account', 101);

insert into DATA_ACCESS_MODEL (DATA_ACCESS_MODEL_ID, MODEL_NAME, DATA_REFERENCE_ID) values (2, 'Postions', 102);