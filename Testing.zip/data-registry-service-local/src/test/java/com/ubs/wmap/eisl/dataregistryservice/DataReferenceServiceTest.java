package com.ubs.wmap.eisl.dataregistryservice;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.ubs.wmap.eisl.dataregistryservice.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataregistryservice.model.DataAccessModel;
import com.ubs.wmap.eisl.dataregistryservice.model.DataFilter;
import com.ubs.wmap.eisl.dataregistryservice.model.DataReference;
import com.ubs.wmap.eisl.dataregistryservice.model.Protocols;
import com.ubs.wmap.eisl.dataregistryservice.repository.DataFilterReferenceRepository;
import com.ubs.wmap.eisl.dataregistryservice.repository.DataModelRepository;
import com.ubs.wmap.eisl.dataregistryservice.repository.DataRefefrenceRepository;
import com.ubs.wmap.eisl.dataregistryservice.repository.ProtocolsRepository;
import com.ubs.wmap.eisl.dataregistryservice.service.impl.DataReferenceServiceImpl;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataAccessModelRequest;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataAccessModelResponse;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataFilterRequest;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataFilterResponse;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataReferenceResponse;
import com.ubs.wmap.eisl.dataregistryservice.vo.ProtocolsRequest;
import com.ubs.wmap.eisl.dataregistryservice.vo.ProtocolsResponse;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.dataregistryservice"})
public class DataReferenceServiceTest{
	
	@Mock
	private DataRefefrenceRepository dataRepo;
	
	@Mock
	private DataModelRepository dataModelRepository;
	
	@Mock
	private ProtocolsRepository protocolsRepository;
	
	@Mock
	private DataFilterReferenceRepository dataFilterReferenceRepository;
	
	@InjectMocks
	private DataReferenceServiceImpl dataService;
	
	@Test
	public void testGetDataReference() throws DataReferenceException {
		//prepare data
		DataReferenceRequest dataReferenceRequest = new DataReferenceRequest();
		dataReferenceRequest.setDataServiceId("TestService1");
		
		DataReference dataReferenceResponse = new DataReference();
		dataReferenceResponse.setDataReferenceId(1);
		dataReferenceResponse.setDataServiceId("TestService1");
		
		DataFilter dataFilter = new DataFilter();
		dataFilter.setFilterId(1);
		dataFilter.setName("filter");
		dataFilter.setOptions("option");
		dataReferenceResponse.setDataFilter(dataFilter);
		
		Set<DataAccessModel> dataModel = new HashSet<>();
		DataAccessModel dataAccessModel = new DataAccessModel();
		dataAccessModel.setDataAccessModelId(1);
		dataAccessModel.setModelName("model");
		dataModel.add(dataAccessModel);
		dataReferenceResponse.setDataModel(dataModel );
		
		Set<Protocols> protocols = new HashSet<>();
		
		Protocols protocol = new Protocols();
		protocol.setProtocolsId(1);
		protocol.setName("Rest");
		protocol.setDetails("restApi");
		protocols.add(protocol);
		dataReferenceResponse.setProtocols(protocols );
		
		
		//Mock repo data
        Mockito.when(dataRepo.findBydataServiceId("TestService1")).thenReturn(dataReferenceResponse);
        
        DataReferenceResponse dataReference = dataService.getDataReference(dataReferenceRequest);
        assertNotNull(dataReference);
        assertEquals("TestService1", dataReference.getDataServiceId());
        assertEquals(new Integer(1), dataReference.getDataReferenceId());
        
        DataFilterResponse dataFil = dataReference.getDataFilter();
        
        assertNotNull(dataFil);
        
        assertEquals(new Integer(1), dataFil.getFilterId());
        assertEquals("filter", dataFil.getName());
        assertEquals("option", dataFil.getOptions());
        
        Set<DataAccessModelResponse> dataAccessModels = dataReference.getDataModel();
        assertNotNull(dataAccessModels);
        assertEquals(1, dataAccessModels.size());
		for (DataAccessModelResponse dataAccessModelResponse : dataAccessModels) {
			assertNotNull(dataAccessModelResponse);
			assertEquals(new Integer(1), dataAccessModelResponse.getDataAccessModelId());
			assertEquals("model", dataAccessModelResponse.getModelName());
		}
		
		Set<ProtocolsResponse> protocolsRes = dataReference.getProtocols();
		assertNotNull(protocolsRes);
		assertEquals(1, protocolsRes.size());
		for (ProtocolsResponse protocolsResponse : protocolsRes) {
			assertNotNull(protocolsResponse);
			assertEquals(new Integer(1), protocolsResponse.getProtocolsId());
			assertEquals("Rest", protocolsResponse.getName());
			assertEquals("restApi", protocolsResponse.getDetails());
		}
	}

	@Test
	public void testPostDataReference() throws DataReferenceException {
		//Mock repo data
        Mockito.when(dataRepo.findById(1)).thenReturn(getDataFReferenceMockedDataById(true));
        Optional<DataReference> dataRefe = getDataFReferenceMockedDataById(false);
        Mockito.when(dataRepo.save( dataRefe.get())).thenReturn(getDataFReferenceMockedDataById(true).get());
        Mockito.when(dataModelRepository.save( getDataAccessModel(false))).thenReturn(getDataAccessModel(true));
        Mockito.when(protocolsRepository.save( getProtocols(false))).thenReturn(getProtocols(true));
        Mockito.when(dataFilterReferenceRepository.save( getDataFilterReference(false))).thenReturn(getDataFilterReference(true));
        DataReferenceResponse saveDataReference = dataService.saveDataReference(getDataReferenceRequest());
        assertNotNull(saveDataReference);
        assertEquals("TestService1", saveDataReference.getDataServiceId());
        assertEquals(new Integer(1), saveDataReference.getDataReferenceId());
	}
	
	private DataFilter getDataFilterReference(boolean isIdRequired){
		DataFilter dataFilterReference = new DataFilter();
		dataFilterReference.setName("filter");
		dataFilterReference.setOptions("option");
		if(isIdRequired) {
			dataFilterReference.setFilterId(1);
		}
		return dataFilterReference;
	}
	
	private DataAccessModel getDataAccessModel(boolean isIdRequired) {

		DataAccessModel dataAccessModel = new DataAccessModel();
		if(isIdRequired) {
			dataAccessModel.setDataAccessModelId(1);
		}
		dataAccessModel.setModelName("model");
		return dataAccessModel;
	}
	
	private Protocols getProtocols(boolean isIdRequired) {
		Protocols protocols = new Protocols();
		if(isIdRequired) {
			protocols.setProtocolsId(1);
			protocols.setName("Rest");
			protocols.setDetails("restApi");
		}
		return protocols;
	}
	
	private DataReferenceRequest getDataReferenceRequest() {
		DataReferenceRequest dataReferenceRequest = new DataReferenceRequest();
		dataReferenceRequest.setDataServiceId("TestService1");
		dataReferenceRequest.setDataReferenceId(1);
		
		DataFilterRequest dataFilterRequest = new DataFilterRequest();
		dataFilterRequest.setName("filter");
		dataFilterRequest.setOptions("option");
		dataReferenceRequest.setDataFilterRequest(dataFilterRequest );
		
		Set<DataAccessModelRequest> dataModelRequest = new HashSet<>();
		
		DataAccessModelRequest dataAccessModelRequest = new DataAccessModelRequest();
		dataAccessModelRequest.setModelName("model");
		dataModelRequest.add(dataAccessModelRequest);
		dataReferenceRequest.setDataModelRequest(dataModelRequest );
		
		Set<ProtocolsRequest> protocolsRequests =new HashSet<>();
		ProtocolsRequest protocolsRequest = new ProtocolsRequest();
		protocolsRequest.setName("Rest");
		protocolsRequest.setDetails("restApi");
		protocolsRequests.add(protocolsRequest);
		dataReferenceRequest.setProtocolsRequest(protocolsRequests);
		
		return dataReferenceRequest;
	}
	
	private Optional<DataReference> getDataFReferenceMockedDataById(boolean isIdRequired) {
		DataReference dataReferenceResponse = new DataReference();
		Optional<DataReference> of = Optional.of(dataReferenceResponse);
		
		if (isIdRequired) {
			dataReferenceResponse.setDataReferenceId(1);
		}
		dataReferenceResponse.setDataServiceId("TestService1");
		
		DataFilter dataFilter = new DataFilter();
		if(isIdRequired) {
			dataFilter.setFilterId(1);
			dataFilter.setName("filter");
			dataFilter.setOptions("option");
		}
		dataReferenceResponse.setDataFilter(dataFilter );
		
		Set<DataAccessModel> dataModel = new HashSet<>();
		DataAccessModel dataAccessModel = new DataAccessModel();
		if (isIdRequired) {
			dataAccessModel.setDataAccessModelId(1);
		}
		dataAccessModel.setModelName("model");
		dataModel.add(dataAccessModel);
		dataReferenceResponse.setDataModel(dataModel );
		
		Set<Protocols> protocols = new HashSet<>();
		Protocols protocol = new Protocols();
		if (isIdRequired) {
			protocol.setProtocolsId(1);
		}
		protocol.setName("Rest");
		protocol.setDetails("restApi");
		protocols.add(protocol);
		dataReferenceResponse.setProtocols(protocols );
		return of;
	}
}
