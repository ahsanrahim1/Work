package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class RoleRequestVO implements Serializable {

	private static final long serialVersionUID = -2710582474336659368L;
	private String publish;
	private String consume;
}
