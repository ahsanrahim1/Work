# security-entitlement-service

# Application startup

Application properties file should be provided
In case of usage application-local.yml properties file (based on application-local.yml.sample file) local runtime profile should be enabled: java -Dspring.profiles.active=local ...

Example with Logback properties
-Dspring.profiles.active=local -DLOGBACK_VARIABLES_FILE=C:\Users\t622900\Work\security-entitlement-service\logback.properties


