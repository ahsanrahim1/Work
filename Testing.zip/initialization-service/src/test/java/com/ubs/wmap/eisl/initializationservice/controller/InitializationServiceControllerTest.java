package com.ubs.wmap.eisl.initializationservice.controller;

import static org.junit.Assert.assertEquals;

import com.ubs.wmap.eisl.initializationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initializationservice.exceptions.InitException;
import com.ubs.wmap.eisl.initializationservice.models.Payload;
import com.ubs.wmap.eisl.initializationservice.service.InitializationService;
import com.ubs.wmap.eisl.initializationservice.service.InitializationServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.mockito.ArgumentMatchers;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.WebApplicationContext;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
@ActiveProfiles("test")
public class InitializationServiceControllerTest {

	@MockBean
    InitializationServiceImpl initilizationServiceimpl;
	
	@Autowired
	WebApplicationContext webApplicationContext;

	@Autowired
    InitializationServiceController initializationServiceController;

    @Test
    public void postInitializationTest() throws BadRequestException, InitException {
        Payload payload = new Payload();
        String eislToken = "Test Eisl Token";
        HashMap<String,Object> map = new HashMap<>();
        map.put("eislToken", eislToken);
        ResponseEntity<HashMap> resp = new ResponseEntity<>(map, HttpStatus.OK);
        Mockito.when(initilizationServiceimpl.generateEislToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(eislToken);
        ResponseEntity<HashMap> result = initializationServiceController.postInitialization("testAuthHead", "testUserId", "testServiceId", "TestRole", payload);
        assertEquals("Success",resp.getBody(),result.getBody());
    }

    @Test
    public void reintializeTest() throws BadRequestException, InitException {
        String eislToken = "Test Eisl Token";
        ResponseEntity<?> resp = new ResponseEntity<>(eislToken,HttpStatus.OK);
        Mockito.when(initilizationServiceimpl.generateEislToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(eislToken);
        ResponseEntity<?> result = initializationServiceController.postInitialization("testAuthHead", eislToken);
        assertEquals("Success",resp.getStatusCode(),result.getStatusCode());
    }

    @Test
    public void terminateTest() throws BadRequestException, InitException {
        Map<String, Object> eislClaims = new HashMap<>();
        eislClaims.put("claims","claims");
        Mockito.when(initilizationServiceimpl.getEislClaims(ArgumentMatchers.anyString())).thenReturn(eislClaims);
        ResponseEntity<?> result = initializationServiceController.terminateInitilization("testAuth", "testEisl");
        assertEquals("succes",HttpStatus.OK,result.getStatusCode());
    }

    @Test
    public void terminateRegNotFoundTest() throws BadRequestException, InitException {
        Map<String, Object> eislClaims = new HashMap<>();
        Mockito.lenient().when(initilizationServiceimpl.getEislClaims(Mockito.anyString())).thenReturn(eislClaims);
        ResponseEntity<?> result = initializationServiceController.terminateInitilization("testAuth", "testEisl");
        assertEquals("succes",HttpStatus.NOT_FOUND,result.getStatusCode());
    }


    @Test(expected = BadRequestException.class)
    public void postInitializationBadRequestTest() throws BadRequestException, InitException{
        Payload payload = new Payload();
        initializationServiceController.postInitialization("TestAuth", "", "testServiceId", "TestRole", payload);
    }

    @Test(expected = BadRequestException.class)
    public void reInitializationBadRequestTest() throws BadRequestException, InitException{
        initializationServiceController.postInitialization("TestAuth", "");
    }

    @Test(expected = BadRequestException.class)
    public void terminateBadRequestTest() throws BadRequestException, InitException{
        initializationServiceController.terminateInitilization("TestAuth", "");
    }


}
