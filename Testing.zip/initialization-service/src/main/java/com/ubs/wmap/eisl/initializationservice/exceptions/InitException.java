package com.ubs.wmap.eisl.initializationservice.exceptions;

public class InitException extends Exception  {
	
	private static final long serialVersionUID = 8089713711480335861L;

	public InitException(String message) {
		super(message);
	}
	

}
