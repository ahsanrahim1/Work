package com.ubs.wmap.eisl.housekeeping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import(TokenServiceConfiguration.class)
public class HousekeepingSecurityServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HousekeepingSecurityServiceApplication.class, args);
	}

}
