package com.ubs.wmap.eisl.initializationservice.service;


import com.ubs.wmap.eisl.housekeeping.component.TokenServiceImpl;
import com.ubs.wmap.eisl.initializationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initializationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initializationservice.models.Payload;
import lombok.extern.slf4j.Slf4j;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@SuppressWarnings("deprecation")
@Slf4j
@RunWith(MockitoJUnitRunner.class)
@ActiveProfiles("test")
public class IntitilizationServiceTest {

    @Mock
    RestTemplate restTemplate;

    @Mock
    TokenServiceImpl tokenService;

    @Mock
    UriComponentsBuilder uriComponentsBuilder;

    @InjectMocks
    InitializationServiceImpl initializationService;
    
    
    @Test
    public void createEislTest() {
    	String testEisl = "Test Eisl";
    	Mockito.when(tokenService.createEILSToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(testEisl);
    	String result = initializationService.generateEislToken("1", "1", "testRole");
    	assertEquals("success",result,testEisl);
    }
    
    @Test
    public void getEislTest() {
    	 String eislToken = "testEisl";
    	 Map<String, Object> eislClaims = new HashMap<>();
    	 eislClaims.put("claims", "testClaims");
    	 Mockito.when(tokenService.init(eislToken)).thenReturn(eislClaims);
    	 Map<String, Object> result = initializationService.getEislClaims(eislToken);
    	 assertEquals("success",eislClaims.get("claims"),result.get("claims"));
    }



    @Test
    public void postRegistrationTest() throws BadRequestException {
        String basicToken = "testBasic";
        Payload payload = new Payload();
        String eislToken = "TestEisl";
        String url="https://localhost:8080";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String, Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request, headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl("https://localhost:8080")
                .queryParam("eislToken", eislToken);
        initializationService.postRegistration(eislToken, basicToken, payload,url);
    }
    

    @Test
    public void deleteRegistration() throws BadRequestException {
        String basicToken = "testBasic";
        Payload payload = new Payload();
        String eislToken = "TestEisl";
        String url="https://localhost:8080";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String, Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request, headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl("https://localhost:8080")
                .queryParam("eislToken", eislToken);
        initializationService.deleteRegistration(basicToken, eislToken,url);
    }

    @Test
    public void putRegistration() {
        String basicToken = "testBasic";
        Payload payload = new Payload();
        String eislToken = "TestEisl";
        String url="https://localhost:8080";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String, Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request, headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl("https://localhost:8080")
                .queryParam("eislToken", eislToken);
        restTemplate.put(builder.toUriString(), String.class, requestEntity);
    }
}


