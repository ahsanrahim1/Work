package com.ubs.wmap.eisl.initializationservice.exceptions;

public class NotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = -7408420202454263359L;

	public NotFoundException(String message) {
		super("Registry not found: "+message);
	}

}
