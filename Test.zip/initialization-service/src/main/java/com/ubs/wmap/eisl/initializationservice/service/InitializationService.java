
package com.ubs.wmap.eisl.initializationservice.service;

import com.ubs.wmap.eisl.initializationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initializationservice.models.Payload;

public interface InitializationService {
    void putRegistration(String basicToken,String eislToken, String registrationServiceEndpoint) throws BadRequestException;
    void deleteRegistration(String basicToken,String eislToken, String registrationServiceEndpoint) throws BadRequestException;
    void postRegistration(String basicToken,String eislToken, Payload payload, String registrationServiceEndpoint) throws BadRequestException;
    
}
