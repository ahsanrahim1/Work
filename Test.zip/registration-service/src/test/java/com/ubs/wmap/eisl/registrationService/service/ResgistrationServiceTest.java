
package com.ubs.wmap.eisl.registrationService.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import com.ubs.wmap.eisl.registrationService.exception.EsilTokenNotValidException;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.model.RoleRequestVO;
import com.ubs.wmap.eisl.registrationService.model.RowReferenceRequestVO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;



@SuppressWarnings("deprecation")
@Slf4j
@RunWith(MockitoJUnitRunner.class)
@ActiveProfiles("test")
public class ResgistrationServiceTest {

	@Mock
	RestTemplate restTemplate;

	@Mock
	TokenService tokenService;

	@InjectMocks
	RegistrationServiceImpl registrationService;
	
    @Value("${registration.service.registryAccessEndpoint}")
    private String registryAccessEndpoint;

    @Value("${registration.service.dataAccessEndpoint}")
    private String dataAccessEndpoint;

    @Value("${registration.service.eventAccessEndpoint}")
    private String eventAccessEndpoint;

    @Value("${registration.service.exceptionAccessEndpoint}")
    private String exceptionAccessEndpoint;


	@Test
	public void getRegistryResponseTest() throws DataNotFoundException, EsilTokenNotValidException {
		RegistrationSO dto = RegistrationSO.builder().build();

		final String url = "http://localhost:5050/eisl/Test";

		HttpHeaders headers = new HttpHeaders();
		headers.add("basicToken", "Test");

		// positive
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", "Test");
		ResponseEntity<RegistrationSO> resp = new ResponseEntity<RegistrationSO>(dto, HttpStatus.OK);
		resp.getBody().setUserId("1");
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
		assertEquals("1", registrationService.getRegistryResponse(url, "Test").getUserId());
	}
	
	@Test
	public void postRegistryResponseTest() throws DataNotFoundException {
		RegistrationSO dto = RegistrationSO.builder().build();

		final String url = "http://localhost:5050/eisl/Test";

		HttpHeaders headers = new HttpHeaders();
		headers.add("basicToken", "Test");
		 MultiValueMap<String, RegistrationSO> map = new LinkedMultiValueMap<String, RegistrationSO>();
	        map.add("payload", dto);
	    HttpEntity<RegistrationSO> requestEntity = new HttpEntity<>(dto);


		
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", "Test");
		ResponseEntity<RegistrationSO> resp = new ResponseEntity<RegistrationSO>(dto, HttpStatus.OK);
		resp.getBody().setUserId("1");
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
		assertEquals("1", registrationService.postRegistryResponse(url, dto, "Test").getUserId());
	}
	
	@Test(expected = DataNotFoundException.class)
	public void postRegistryResponseDataNotFounfTest() throws DataNotFoundException {
		RegistrationSO dto = RegistrationSO.builder().build();

		final String url = "http://localhost:5050/eisl/Test";

		HttpHeaders headers = new HttpHeaders();
		headers.add("basicToken", "Test");
		 MultiValueMap<String, RegistrationSO> map = new LinkedMultiValueMap<String, RegistrationSO>();
	        map.add("payload", dto);
	    HttpEntity<RegistrationSO> requestEntity = new HttpEntity<>(dto);


		
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", "Test");
		ResponseEntity<RegistrationSO> resp = new ResponseEntity<RegistrationSO>(dto, HttpStatus.OK);
		resp.getBody().setUserId("1");
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenThrow(DataNotFoundException.class);
		assertEquals("1", registrationService.postRegistryResponse(url, dto, "Test").getUserId());
	}
	
	
	@Test
	public void putRegistryResponseTest() throws InvalidDataException {
		RegistrationSO dto = RegistrationSO.builder().build();

		final String url = "http://localhost:5050/eisl/Test";

	   
		ResponseEntity<RegistrationSO> resp = new ResponseEntity<RegistrationSO>(dto, HttpStatus.OK);
		resp.getBody().setUserId("1");
		 UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("registrationData",
		    		dto);
		Mockito.when(restTemplate.exchange(builder.toUriString(), HttpMethod.PUT, null,
				new ParameterizedTypeReference<RegistrationSO>() {
				})).thenReturn(resp);
		assertEquals(resp.getBody(), registrationService.putRegistryResponse(url, dto));
	}
	
	@Test(expected = InvalidDataException.class)
	public void putRegistryResponseInvalidDataTest() throws InvalidDataException {
		RegistrationSO dto = RegistrationSO.builder().build();

		final String url = "http://localhost:5050/eisl/Test";

	   
		ResponseEntity<RegistrationSO> resp = new ResponseEntity<RegistrationSO>(dto, HttpStatus.OK);
		resp.getBody().setUserId("1");
		 UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("registrationData",
		    		dto);
		Mockito.when(restTemplate.exchange(builder.toUriString(), HttpMethod.PUT, null,
				new ParameterizedTypeReference<RegistrationSO>() {
				})).thenThrow(InvalidDataException.class);
		registrationService.putRegistryResponse(url, dto);
	}
	
	@Test(expected = DataNotFoundException.class)
	public void getEventResponseDataNotFoundTest() throws DataNotFoundException
	{
		final String url = "http://localhost:5050/eisl/Test";
		String eislToken = "testEisl";
        ResponseEntity<String> resp = new ResponseEntity<String>(eislToken,HttpStatus.OK);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken);
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenThrow(DataNotFoundException.class);
        registrationService.getEventsResponse(url, eislToken);
	}
	
	@Test
	public void getEventResponse() throws DataNotFoundException
	{
		final String url = "http://localhost:5050/eisl/Test";
		String eislToken = "testEisl";
        ResponseEntity<String> resp = new ResponseEntity<String>(eislToken,HttpStatus.OK);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken);
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
        assertEquals(resp.getBody(),registrationService.getEventsResponse(url, eislToken));
	}

	@Test
	public void getDataResponse() throws DataNotFoundException
	{
		final String url = "http://localhost:5050/eisl/Test";
		String eislToken = "testEisl";
		String dataId = "testId";
        ResponseEntity<String> resp = new ResponseEntity<String>(eislToken,HttpStatus.OK);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken).queryParam("dataServiceId", dataId);
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
        assertEquals(resp.getBody(),registrationService.getDataResponse(url, eislToken, dataId));
	}
	
	@Test(expected = DataNotFoundException.class )
	public void getDataResponseDataNotFound() throws DataNotFoundException
	{
		final String url = "http://localhost:5050/eisl/Test";
		String eislToken = "testEisl";
		String dataId = "testId";
        ResponseEntity<String> resp = new ResponseEntity<String>(eislToken,HttpStatus.OK);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken).queryParam("dataServiceId", dataId);
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenThrow(DataNotFoundException.class);
        registrationService.getDataResponse(url, eislToken, dataId);
	}
	
	@Test
	public void getExceptionResponse() throws DataNotFoundException
	{
		final String url = "http://localhost:5050/eisl/Test";
		String eislToken = "testEisl";
		String dataId = "testId";
        ResponseEntity<String> resp = new ResponseEntity<String>("Test",HttpStatus.OK);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken).queryParam("exceptionServiceId", dataId);
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
        assertEquals(resp.getBody(),registrationService.getExceptionsResponse(url, eislToken, dataId));
	}
	
	@Test(expected = DataNotFoundException.class)
	public void getExceptionResponseDataNotFoundTest() throws DataNotFoundException
	{
		final String url = "http://localhost:5050/eisl/Test";
		String eislToken = "testEisl";
		String dataId = "testId";
        ResponseEntity<String> resp = new ResponseEntity<String>("Test",HttpStatus.OK);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken).queryParam("exceptionServiceId", dataId);
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenThrow(DataNotFoundException.class);
        registrationService.getExceptionsResponse(url, eislToken, dataId);
	}
	
	@Test
	public void deleteRegistration() {
		final String url = "http://localhost:5050/eisl/Test";
		String eislToken = "testEisl";
		String basicToken = "testBasic";
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("basicToken", basicToken);
		HttpEntity<ResponseSO> requestEntity = new HttpEntity<>(headers);
        
		ResponseSO responseSO = new ResponseSO();
		
		ResponseEntity<ResponseSO> resp = new ResponseEntity<ResponseSO>(responseSO,HttpStatus.OK);
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("basicToken", basicToken)
				.queryParam("eislToken", eislToken);
		Mockito.when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(), ArgumentMatchers.any(ParameterizedTypeReference.class))).thenReturn(resp);
        assertEquals(resp.getBody(),registrationService.deleteRegistration(url, eislToken));
	}
	

    @Test
    public void getEislTest() {
    	 String eislToken = "testEisl";
    	 Map<String, Object> eislClaims = new HashMap<>();
    	 eislClaims.put("claims", "testClaims");
    	 Mockito.when(tokenService.init(eislToken)).thenReturn(eislClaims);
    	 Map<String, Object> result = registrationService.getEislClaims(eislToken);
    	 assertEquals("success",eislClaims.get("claims"),result.get("claims"));
    }
	

	
}
