package com.ubs.wmap.eisl.registrationService.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.validation.constraints.NotBlank;

//import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.model.RoleRequestVO;
import com.ubs.wmap.eisl.registrationService.model.RowReferenceRequestVO;

import io.jsonwebtoken.Claims;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegistrationServiceImpl implements RegistrationService {


	private final RestTemplate restTemplate;

	private final TokenService tokenService;

	@Value("${registration.service.registryAccessEndpoint}")
	private String registryAccessEndpoint;

	@Value("${registration.service.dataAccessEndpoint}")
	private String dataAccessEndpoint;

	@Value("${registration.service.eventAccessEndpoint}")
	private String eventAccessEndpoint;

	@Value("${registration.service.exceptionAccessEndpoint}")
	private String exceptionAccessEndpoint;


	@Override
	public boolean validateToken(String basicToken, String eislToken) {
		boolean isValid = tokenService.isEISLTokenValid(eislToken);
		return isValid;

	}
	

	public RegistrationSO getRegistryResponse(String baseUrl, String firstParam, String stringParam) throws DataNotFoundException {

      final String url = String.format("/eisl/%s", baseUrl);

		HttpHeaders headers = new HttpHeaders();
		headers.add("basicToken", firstParam);


		Claims claims = tokenService.unwrapEislToken(stringParam);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", stringParam);

		try {
			final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					null, new ParameterizedTypeReference<RegistrationSO>() {
					});
			return responseDto.getBody();
		}catch(HttpStatusCodeException e){
            throw new DataNotFoundException("No Data Found");
		}
	}

	public RegistrationSO postRegistryResponse(String baseUrl, RegistrationSO registrationData,String eislToken) {

       final String url = String.format("/eisl/%s", baseUrl);
	

		MultiValueMap<String, RegistrationSO> map = new LinkedMultiValueMap<String, RegistrationSO>();
		map.add("payload", registrationData);

		HttpEntity<RegistrationSO> requestEntity = new HttpEntity<>(registrationData);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken);

		final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
				requestEntity, new ParameterizedTypeReference<RegistrationSO>() {
				});
		return responseDto.getBody();
	}

	public RegistrationSO putRegistryResponse(String baseUrl, RegistrationSO registrationData) throws InvalidDataException {

       final String url = String.format("/eisl/%s", baseUrl);


		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("registrationData",
				registrationData);

		try {
			final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.PUT,
					null, new ParameterizedTypeReference<RegistrationSO>() {
					});
			return responseDto.getBody();
		}catch(HttpStatusCodeException e){
			throw new InvalidDataException();
		}
	}

	public String getEventsResponse(String baseUrl, String firstParam, String stringParam) throws DataNotFoundException {

       final String url = String.format("/eisl/%s", baseUrl);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", stringParam);
        try {
			final ResponseEntity<String> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					null, new ParameterizedTypeReference<String>() {
					});
			return responseDto.toString();
		}catch(HttpStatusCodeException e){
            throw new DataNotFoundException("No Data Found");
		}
	}

	public String getDataResponse(String baseUrl, String firstParam, String stringParam,
			String basicToken) throws DataNotFoundException {

       final String url = String.format("/eisl/%s", baseUrl);


		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", firstParam)
				.queryParam("dataServiceId", stringParam);

		try {
		final ResponseEntity<String> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
				null, new ParameterizedTypeReference<String>() {
				});
		return responseDto.toString();
		}catch(HttpStatusCodeException e) {
            throw new DataNotFoundException("No Data Found");
		}
	}

	public String getExceptionsResponse(String baseUrl, String firstParam,
			String exceptionServiceId, String basicToken) throws DataNotFoundException {

		final String url = String.format("/eisl/%s", baseUrl);
        	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", firstParam)
				.queryParam("exceptionServiceId", exceptionServiceId);
		try {
		final ResponseEntity<String> responseDto = restTemplate.exchange(builder.toUriString(),
				HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
				});
		return responseDto.toString();
		}catch(HttpStatusCodeException e) {
            throw new DataNotFoundException("No Data Found");
		}

	}

	@Override
	public ResponseSO deleteRegistration(String baseUrl, String basicToken, String eislToken) {
		final String url = String.format("/eisl/%s", baseUrl);

		HttpHeaders headers = new HttpHeaders();
		headers.add("basicToken", basicToken);

		HttpEntity<ResponseSO> requestEntity = new HttpEntity<>(headers);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("basicToken", basicToken)
				.queryParam("eislToken", eislToken);

		final ResponseEntity<ResponseSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE,
				requestEntity, new ParameterizedTypeReference<ResponseSO>() {
				});
		return responseDto.getBody();
	}

	@Override
	public RegistrationSO postRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadSO payload)
            throws InvalidDataException, DataNotFoundException {

		ObjectMapper mapper = new ObjectMapper();
		RegistrationSO responseDTO = RegistrationSO.builder().build();
		RegistrationSO getResponse = getRegistryResponse(registryAccessEndpoint, basicToken, eislToken);
		if (getResponse!= null) {
			return getResponse;
		}
		String eventsResponse = getEventsResponse(eventAccessEndpoint, basicToken, eislToken);
		Map<String,Object> events = new HashMap<String,Object>();
		try {
			events = mapper.readValue(eventsResponse, new TypeReference<Map<String, String>>(){});
		} catch (IOException e) {
		    log.error("No event Data found");
            throw new InvalidDataException();
		}
		String dataResponse = getDataResponse(dataAccessEndpoint, eislToken,
				events.get("dataReferenceId").toString(), basicToken);
		String exceptionResponse = getExceptionsResponse(exceptionAccessEndpoint, eislToken,
				events.get("excetionReferenceId").toString(), basicToken);
		if (eventsResponse.isEmpty()
				|| dataResponse.isEmpty()
				|| exceptionResponse.isEmpty()) {
			throw new InvalidDataException();
		}
		RegistrationSO builtRegistry = buildRegistration(payload, eislToken);
		RegistrationSO postResponse = postRegistryResponse(registryAccessEndpoint, builtRegistry,eislToken);
		return postResponse;
	}

	@Override
	public RegistrationSO putRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadSO payload)
            throws InvalidDataException, DataNotFoundException {

		ObjectMapper mapper = new ObjectMapper();
		RegistrationSO responseDTO = RegistrationSO.builder().build();
		RegistrationSO getResponse = getRegistryResponse(eventAccessEndpoint, basicToken, eislToken);
		if (getResponse !=null) {
			return getResponse;
		}
		String eventsResponse = getEventsResponse(eventAccessEndpoint, basicToken, eislToken);
		Map<String,Object> events = new HashMap<String,Object>();
		try {
			events = mapper.readValue(eventsResponse, new TypeReference<Map<String, String>>(){});
		} catch (IOException e) {
            log.error("No event Data found");
            throw new InvalidDataException();
		}
		String dataResponse = getDataResponse(dataAccessEndpoint, eislToken,
				events.get("dataReferenceId").toString(), basicToken);
		String exceptionResponse = getExceptionsResponse(exceptionAccessEndpoint, eislToken,
				events.get("excetionReferenceId").toString(), basicToken);
		if (eventsResponse.isEmpty()
				|| dataResponse.isEmpty()
				|| exceptionResponse.isEmpty()) {
			throw new InvalidDataException();
		}
		RegistrationSO builtRegistry = buildRegistration(payload, eislToken);
		RegistrationSO putResponse = putRegistryResponse(registryAccessEndpoint, builtRegistry);
		return putResponse;
	}

	public RegistrationSO buildRegistration(PayloadSO payload, String eislToken) {
		Claims claims = tokenService.unwrapEislToken(eislToken);
		//Data for Testing
		Set<ColumnReferenceRequestVO> colRefSet = new HashSet<ColumnReferenceRequestVO>();
		ColumnReferenceRequestVO colRef = new ColumnReferenceRequestVO();
		colRef.setName("testName");
		colRef.setType("TestType");
		colRefSet.add(colRef);
		Set<RowReferenceRequestVO> rowRefSet = new HashSet<RowReferenceRequestVO>();
		RowReferenceRequestVO rowRef = new RowReferenceRequestVO();
		rowRef.setName("TestName");
		rowRef.setType("TestType");
		rowRefSet.add(rowRef);
		RoleRequestVO role = new RoleRequestVO();
		role.setConsume("TestConsume");
		role.setPublish("TestPublish");
		String sampleDataEnti = "This is a sample of data entitlement";
		//Data for testing
		RegistrationSO builtRegistration = RegistrationSO.builder().userName(claims.get("userName").toString())
				.company(payload.getCompany()).eislToken(eislToken)
				.serviceId(claims.get("serviceId").toString()).userId(payload.getUserId()).columnReferences(colRefSet)
				.rowReferences(rowRefSet).dataEntitlement(sampleDataEnti).role(role).build();
		return builtRegistration;
	}

	@Override
	public ResponseSO getRegistration(@NotBlank String basicToken, @NotBlank String eislToken)
            throws InvalidDataException, DataNotFoundException {
 
		ObjectMapper mapper = new ObjectMapper();
		ResponseSO responseDTO = new ResponseSO();
		Map<String,Object> responseMap = new HashMap<>();
        RegistrationSO getResponse;
		try {
             getResponse = getRegistryResponse(registryAccessEndpoint, basicToken, eislToken);
        }
		catch (DataNotFoundException ex) {
			throw new InvalidDataException("Registry not found");
		}
		Map<String,Object> registration = new HashMap<String,Object>();
		String eventsResponse = getEventsResponse(eventAccessEndpoint, basicToken, eislToken).toString();
		Map<String,Object> events = new HashMap<String,Object>();
		Map<String,Object> data = new HashMap<String,Object>();
		Map<String,Object> exception = new HashMap<String,Object>();
		try {
			registration = mapper.readValue(getResponse.toString(),new TypeReference<Map<String, String>>(){});
			events = mapper.readValue(eventsResponse, new TypeReference<Map<String, String>>(){});
			String dataResponse = getDataResponse(dataAccessEndpoint, eislToken,events.get("dataServiceId").toString(),basicToken).toString();
			String exceptionResponse = getExceptionsResponse(exceptionAccessEndpoint, eislToken,events.get("exceptionServiceId").toString(), basicToken).toString();
			data = mapper.readValue(dataResponse, new TypeReference<Map<String, String>>(){});
			exception = mapper.readValue(exceptionResponse, new TypeReference<Map<String, String>>(){});

		} catch (IOException e) {
            log.error("Data not found");
		}
		responseMap.put("registration", registration);
		responseMap.put("events", events);
		responseMap.put("data", data);
		responseMap.put("exception", exception);
		
		responseDTO.setResponse(responseMap);
		
		return responseDTO;
	}
}
