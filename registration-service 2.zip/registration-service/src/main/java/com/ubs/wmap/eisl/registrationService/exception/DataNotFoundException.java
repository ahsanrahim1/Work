package com.ubs.wmap.eisl.registrationService.exception;

public class DataNotFoundException extends Exception{
    public DataNotFoundException(String message) {
        super(message);
    }
}
