package com.ubs.wmap.eisl.initilizationservice.controller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.ubs.wmap.eisl.initilizationservice.controller.InitilizationServiceController;
import com.ubs.wmap.eisl.initilizationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initilizationservice.exceptions.InitException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;
import com.ubs.wmap.eisl.initilizationservice.service.InitilizationServiceImpl;

import io.micrometer.core.instrument.util.StringUtils;

import java.util.HashMap;
import lombok.extern.slf4j.Slf4j;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.matchers.Any;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
public class IntitilizationControllerTest {
    
    @Mock
    InitilizationServiceImpl initilizationServiceimpl;
    
    @InjectMocks
    InitilizationServiceController initilizationServiceController;
    
    @Test
    public void postInitializationTest() throws BadRequestException, InitException{
        Payload payload = new Payload();
        String eislToken = "Test Eisl Token";
        HashMap<String,Object> map = new HashMap<>();
        map.put("eislToken", eislToken);
        ResponseEntity<HashMap> resp = new ResponseEntity<>(map,HttpStatus.OK);
        Mockito.when(initilizationServiceimpl.generateEislToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(eislToken);
        ResponseEntity<HashMap> result = initilizationServiceController.postInitialization("testAuthHead", "testUserId", "testServiceId", "TestRole", payload);
        assertEquals("Success",resp.getBody(),result.getBody());
    }
    
    @Test
    public void reintializeTest() throws BadRequestException, InitException {
    	String eislToken = "Test Eisl Token";
        ResponseEntity<?> resp = new ResponseEntity<>(eislToken,HttpStatus.OK);
        Mockito.when(initilizationServiceimpl.generateEislToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(eislToken);
        ResponseEntity<?> result = initilizationServiceController.postInitialization("testAuthHead", eislToken);
        assertEquals("Success",resp.getStatusCode(),result.getStatusCode());
    }
    
    @Test
    public void terminateTest() throws BadRequestException, InitException {
    	Mockito.when(initilizationServiceimpl.validateEislToken(ArgumentMatchers.anyString())).thenReturn(true);
    	ResponseEntity<?> result = initilizationServiceController.terminateInitilization("testAuth", "testEisl");
    	assertEquals("succes",HttpStatus.OK,result.getStatusCode()); 
    }
    
    @Test
    public void terminateRegNotFoundTest() throws BadRequestException, InitException {
    	Mockito.when(initilizationServiceimpl.validateEislToken(ArgumentMatchers.anyString())).thenReturn(false);
    	ResponseEntity<?> result = initilizationServiceController.terminateInitilization("testAuth", "testEisl");
    	assertEquals("succes",HttpStatus.NOT_FOUND,result.getStatusCode()); 
    }
    
    
    @Test(expected = BadRequestException.class)
    public void postInitializationBadRequestTest() throws BadRequestException, InitException{
        Payload payload = new Payload();
        initilizationServiceController.postInitialization("TestAuth", "", "testServiceId", "TestRole", payload);
    }
    
    @Test(expected = BadRequestException.class)
    public void reInitializationBadRequestTest() throws BadRequestException, InitException{
        initilizationServiceController.postInitialization("TestAuth", "");
    }
    
    @Test(expected = BadRequestException.class)
    public void terminateBadRequestTest() throws BadRequestException, InitException{
        initilizationServiceController.terminateInitilization("TestAuth", "");
    }
    
    
    
    
   
}
