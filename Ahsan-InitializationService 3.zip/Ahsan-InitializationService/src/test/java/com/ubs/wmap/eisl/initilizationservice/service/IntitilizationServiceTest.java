/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ubs.wmap.eisl.initilizationservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
public class IntitilizationServiceTest {
    
    @Mock
    RestTemplate restTemplate;

    @Mock
    TokenService tokenService;
    
    @InjectMocks
    InitilizationServiceImpl initilizationServiceImpl;

    
    @Test
    public void eislTokenValidTest(){
        boolean isValid = true;
        Mockito.when(tokenService.isEISLTokenValid(ArgumentMatchers.anyString())).thenReturn(isValid);
        assertTrue("valid",initilizationServiceImpl.validateEislToken("testEislToken"));   
    }
    
    
    @Test
    public void generateEislTest(){
       String respEisl = "testEisl";
       Mockito.when(tokenService.init(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(respEisl);
       assertEquals("Success",respEisl,initilizationServiceImpl.generateEislToken("testUserId", "testServiceId", "testRole"));
    }
    
    @Test(expected = InvalidEislTokenException.class)
    public void InvalidEislException() {
       Mockito.when(tokenService.init(ArgumentMatchers.anyString(), ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenThrow(InvalidEislTokenException.class);
       initilizationServiceImpl.generateEislToken("testUserId", "testServiceId", "testRole");
    }
    
    @Test(expected = InvalidEislTokenException.class)
    public void InvalideislTokenTest(){
        Mockito.when(tokenService.isEISLTokenValid(ArgumentMatchers.anyString())).thenThrow(InvalidEislTokenException.class);
        initilizationServiceImpl.validateEislToken("testEislToken");   
    }
    
    @Test
    public void postRegistrationTest() {
    	String basicToken = "testBasic";
    	String testUrl = "http://localhost:8080/test";
    	Payload payload = new Payload();
    	String eislToken = "TestEisl";
    	initilizationServiceImpl.postRegistration(basicToken, eislToken, payload);    	
    }
    
    @Test
    public void deleteRegistration() {
    	initilizationServiceImpl.deleteRegistration("TestBasic", "TestEisl");
    }
    
    @Test
    public void putRegistration() {
    	initilizationServiceImpl.putRegistration("TestBasic", "TestEisl");
    }
    
    
    
    
    
   
}

