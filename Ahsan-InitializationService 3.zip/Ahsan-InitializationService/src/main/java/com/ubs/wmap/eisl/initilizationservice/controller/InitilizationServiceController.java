
package com.ubs.wmap.eisl.initilizationservice.controller;

import com.ubs.wmap.eisl.initilizationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initilizationservice.exceptions.InitException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;
import com.ubs.wmap.eisl.initilizationservice.service.InitilizationServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;

import java.util.HashMap;

import static org.apache.commons.lang3.StringUtils.isEmpty;


@RestController
@Slf4j
@RequestMapping(value = "/eisl/intialization/v1", produces = "application/json")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InitilizationServiceController {
    

    private final InitilizationServiceImpl initializationService;

    @Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
    private String INTERNAL_SERVER_ERROR_MSG;

    @Value("${app.message.BASIC_TOKEN_EMPTY_MSG}")
    private String BASIC_TOKEN_EMPTY_MSG;

    @Value("${app.message.EISL_TOKEN_EMPTY_MSG}")
    private String EISL_TOKEN_EMPTY_MSG;

    @Value("${app.message.EISL_INVALID_TOKEN_MSG}")
    private String EISL_INVALID_TOKEN_MSG;

    @Value("${app.message.INVALID_REQUEST}")
    private String INVALID_REQUEST;



    @PostMapping(value = "/initialize")
    public ResponseEntity<HashMap> postInitialization(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                @NotBlank @RequestParam("userId") final String userId,
                                                @NotBlank @RequestParam("serviceId") final String serviceId,
                                                @NotBlank @RequestParam("Role") final String role,
                                                @RequestBody Payload payload) throws BadRequestException, InitException
    {
        String basicToken = trimAuthorizationSchema(authHeader);

        if (isEmpty(userId) || isEmpty(serviceId) || isEmpty(role)) {
            throw new BadRequestException(INVALID_REQUEST);
        }

        String eislToken = initializationService.generateEislToken(userId, serviceId, role);
        try {
            initializationService.postRegistration(basicToken, eislToken, payload);
            return ResponseEntity.ok().body(new HashMap<String, Object>() {{put("eislToken", eislToken);}});
        } catch (Exception ex) {
            log.warn("Exception Occurred: {}", ex);
            throw new InitException(ex.getMessage());
        }
        
    }

    @PostMapping(value = "/reinitialize")
    public ResponseEntity<HashMap> postInitialization(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                @NotBlank @RequestParam("token") final String eislToken) throws BadRequestException, InitException
    {
        String basicToken = trimAuthorizationSchema(authHeader);

        if (isEmpty(eislToken)) {
            throw new BadRequestException(INVALID_REQUEST);
        }

        try {
            String ValidatedEislToken = initializationService.generateEislToken(basicToken, eislToken, null);
            initializationService.putRegistration(basicToken, ValidatedEislToken);
            return ResponseEntity.ok().body(new HashMap<String, Object>() {{put("eislToken", ValidatedEislToken);}});
        } catch (Exception ex) {
            log.warn("Exception Occurred: {}", ex);
            throw new InitException(ex.getMessage());
        }

    }

    @DeleteMapping(value = "/initialize")
    public ResponseEntity<?> terminateInitilization(@NotBlank @RequestHeader (name = "Authorization") final String authHeader,
                                                    @NotBlank @RequestParam("token") final String eislToken ) throws BadRequestException, InitException
    {
        String basicToken = trimAuthorizationSchema(authHeader);

        if (isEmpty(eislToken)) {
            throw new BadRequestException(INVALID_REQUEST);
        }

        try {
            if(initializationService.validateEislToken(eislToken)){
                initializationService.deleteRegistration(basicToken, eislToken);
                return ResponseEntity.ok().build();
            }
            else {
                return ResponseEntity.notFound().build();
            }

        } catch (Exception ex) {
            log.warn("Exception Occurred: {}", ex);
            throw new InitException(ex.getMessage());
        }
    }

    private String trimAuthorizationSchema(String authorizationHeader) {
        return authorizationHeader.replaceAll("^Bearer ", "");
    }
    
}
