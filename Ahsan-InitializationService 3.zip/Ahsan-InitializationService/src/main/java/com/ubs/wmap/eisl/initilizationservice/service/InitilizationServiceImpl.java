
package com.ubs.wmap.eisl.initilizationservice.service;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.initilizationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InitilizationServiceImpl implements InitilizationService{


    private final RestTemplate restTemplate;

    private final TokenService tokenService;

    @Value("${service.registrationServiceEndpoint}")
    private String registrationServiceEndpoint;

    
    public boolean validateEislToken(String eislToken) throws InvalidEislTokenException {
        try{
        boolean isValid = tokenService.isEISLTokenValid(eislToken);
        return isValid;
        }
        catch(Exception e){
          throw new InvalidEislTokenException(e.getMessage());
        }
    }
    
    public String generateEislToken(String userId, String serviceId,String role) throws InvalidEislTokenException{
        try{
        String newToken = tokenService.init(userId, serviceId, role);
        return newToken;
        }catch(Exception e)
        {
            throw new InvalidEislTokenException(e.getMessage());
        }
    }
    
    @Override
    public void postRegistration(String basicToken,String eislToken, Payload payload){
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String,Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request,headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(registrationServiceEndpoint).queryParam("eislToken", eislToken);
       
        restTemplate.postForObject(builder.toUriString(), requestEntity, String.class);
    }
    
    @Override
    public void putRegistration(String basicToken,String eislToken){
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String,Object> request = new LinkedMultiValueMap<>();
        HttpEntity<Object> requestEntity = new HttpEntity<>(request,headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(registrationServiceEndpoint).queryParam("eislToken", eislToken);
        restTemplate.put(builder.toUriString(), String.class, requestEntity);
    }
    
    @Override
    public void deleteRegistration(String basicToken,String eislToken){
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(registrationServiceEndpoint).queryParam("eislToken", eislToken);
        restTemplate.delete(builder.toUriString(), requestEntity);   
    }
    
    
    
}
