
package com.ubs.wmap.eisl.initilizationservice.service;

import com.ubs.wmap.eisl.initilizationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;

public interface InitilizationService {
    void putRegistration(String basicToken,String eislToken);
    void deleteRegistration(String basicToken,String eislToken);
    void postRegistration(String basicToken,String eislToken, Payload payload) throws BadRequestException;
    
}
