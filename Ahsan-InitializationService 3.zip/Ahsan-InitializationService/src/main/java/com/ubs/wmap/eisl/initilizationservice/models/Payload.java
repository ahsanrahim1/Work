
package com.ubs.wmap.eisl.initilizationservice.models;

import lombok.Data;

@Data
public class Payload {
    String userName;
    String company;
    
}
