
package com.ubs.wmap.eisl.initilizationservice.controller;

import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;
import com.ubs.wmap.eisl.initilizationservice.service.InitilizationServiceImpl;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author ahsanrahim
 */
//@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController(value = "/eisl/intialization/v1/registrations")
public class ReinitializationController {
    
    @Autowired
    private  InitilizationServiceImpl reInitializationService;

    @RequestMapping(value = "/intialization/v1/registrations", method = RequestMethod.POST)
    public ResponseEntity<?> postInitialization(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
            @NotBlank @RequestParam("eislToken") final String eislToken,@RequestBody Payload payload) throws InvalidEislTokenException
    {
        try {
            String ValidatedEislToken = reInitializationService.generateEislToken(basicToken, eislToken, null);
            reInitializationService.putRegistration(basicToken, ValidatedEislToken, payload);
            return ResponseEntity.ok().body(eislToken);
        } catch (InvalidEislTokenException ex) {
            Logger.getLogger(ReinitializationController.class.getName()).log(Level.SEVERE, null, ex);
            throw new InvalidEislTokenException("Token could not be refreshed");
        }

    }

}
