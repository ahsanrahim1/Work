
package com.ubs.wmap.eisl.initilizationservice.controller;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.service.InitilizationServiceImpl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author ahsanrahim
 */
@Slf4j
//@RequiredArgsConstructor(onConstructor = @_(@Autowired))
@RestController
public class TerminateController {

    @Autowired
    private  InitilizationServiceImpl initializationService;


    @RequestMapping(value = "/intialization/v1/registrations", method = RequestMethod.DELETE)
    public ResponseEntity<?> terminateInitilization(@NotBlank @RequestHeader (name = "basicToken") final String basicToken,
            @NotBlank @RequestParam("eislToken") final String eislToken ) throws InvalidEislTokenException
    {
        try {
            //log.debug("Entering Terminate Sequence");
            boolean isValid = initializationService.validateEislToken(eislToken);
            initializationService.deleteRegistration(basicToken, eislToken);
            return ResponseEntity.ok().build();
        } catch (InvalidEislTokenException ex) {
            //log.error("Eisl Token Invalid");
            throw new InvalidEislTokenException("EislTokenNotValid");
        }
    }
}
