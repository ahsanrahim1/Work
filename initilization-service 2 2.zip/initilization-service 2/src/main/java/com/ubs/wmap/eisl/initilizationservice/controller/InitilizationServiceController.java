
package com.ubs.wmap.eisl.initilizationservice.controller;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;
import com.ubs.wmap.eisl.initilizationservice.service.InitilizationServiceImpl;

import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author ahsanrahim
 */
@Slf4j
//@AllArgsConstructor(onConstructor = @__(@Autowired))
@RestController(value = "/eisl")
public class InitilizationServiceController {
    
    @Autowired
    private  InitilizationServiceImpl initializationService;
    
    @RequestMapping(value = "/intialization/v1/registrations", method = RequestMethod.POST)
    public ResponseEntity<?> postInitialization(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
            @NotBlank @RequestParam("Role") final String Role, @NotBlank @RequestParam("userId") final String userId, @NotBlank @RequestParam("serviceId") final String serviceId,@RequestBody Payload payload) throws InvalidEislTokenException
    {
        try {
            //log.debug("Entering Intialization Sequence");
            String eislToken = initializationService.generateEislToken(basicToken, null, userId);
            initializationService.postRegistration(basicToken, eislToken, payload);
            return ResponseEntity.ok().body(eislToken);
        } catch (InvalidEislTokenException ex) {
            //log.error("Eisl Token could not be built");
            throw new InvalidEislTokenException("Insufficent Data to build Eisl Token");
        }
        
    }
    
}
