package com.ubs.wmap.eisl.registryaccessservice.service;

import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;


/**
 * @author Gananath
 *
 */
public interface RegistryReferenceService {
	
	/**
	 * @param registryAccessRequestVO
	 * @return RegistrationResponseVO
	 * @throws RegistryReferenceException
	 */
	public RegistrationResponseVO getRegistryReference(RegistryAccessRequestVO registryAccessRequestVO)
			throws RegistryReferenceException;
	
	
	/**
	 * @param registrationRequestVO
	 * @return
	 * @throws RegistryReferenceException
	 */
	public RegistrationResponseVO persistRegistry(RegistrationRequestVO registrationRequestVO)throws RegistryReferenceException;
	
}
