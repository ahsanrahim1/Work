package com.ubs.wmap.eisl.registryaccessservice.constant;

public interface RegistryAccessConstant {

	   public static final String REGISTRY_ACCESS_NOT_FOUND = "Data reference not found";
	   public static final String INTERNAL_SERVER_ERROR_MSG="Internal server error occured";
	   public static final String REGISTRY_ACCESS_ENDPOINT="/eisl/user/v1/registrations";
	}
