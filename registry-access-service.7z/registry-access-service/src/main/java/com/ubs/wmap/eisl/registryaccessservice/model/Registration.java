package com.ubs.wmap.eisl.registryaccessservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
@Entity
@Table(name = "REGISTRATION")
public class Registration implements Serializable{

	private static final long serialVersionUID = 3770085916847755446L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "REGISTRATION_ID")
	private Long registrationId;
	
	@Column(name = "USER_NAME")
	private String userName;
	
	@Column(name = "USER_ID")
	private String userId;
	
	@Column(name = "COMPANY")
	private String company;
	
	@Column(name = "EISL_TOKEN")
	private String eislToken;
	
	@Column(name = "SERVICE_ID")
	private String serviceId;
	
	@Column(name = "DATA_ENTITLEMENT")
	private String dataEntitlement;
	
	@EqualsAndHashCode.Exclude
	@OneToOne(mappedBy = "registration", cascade = CascadeType.ALL, fetch =
	  FetchType.LAZY, optional = false)	
	private Roles Role;	
	
	@EqualsAndHashCode.Exclude
	@OneToMany(mappedBy="registration", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<ColumnReference> columnReferences;
	
	@EqualsAndHashCode.Exclude
	@OneToMany(mappedBy="registration", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<RowReference> rowReferences;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;
	
	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATION_DATE", updatable = false)
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	@Column(name = "LAST_UPDATED_DATE")
	private Date lastUpdatedDate;
	
}
