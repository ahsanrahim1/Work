package com.ubs.wmap.eisl.ms.eventregistry.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.ms.eventregistry.controller.delegates.EventDelegate;
import com.ubs.wmap.eisl.ms.eventregistry.exception.EventBadRequestException;
import com.ubs.wmap.eisl.ms.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.ms.eventregistry.exception.EventNotFoundException;
import com.ubs.wmap.eisl.ms.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.ms.eventregistry.services.sos.EventResponseSO;
import com.ubs.wmap.eisl.ms.eventregistry.util.EislClaimsContextUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@Slf4j
public class EventController {

	private final EventDelegate eventDelegate;

	private final EislClaimsContextUtil eislClaimsContextUtil;

	@Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;

	@Value("${app.message.EVENT_NOT_FOUND_MSG}")
	private String EVENT_NOT_FOUND_MSG;
	
	@Value("${app.message.SERVICE_ID_EMPTY_MSG}")
	private String SERVICE_ID_EMPTY_MSG;

	@RequestMapping(value = "/eisl/event/v1/events", method = RequestMethod.GET)
	public ResponseEntity<EventResponseSO> getEventDetails()
			throws EventException, EventBadRequestException, EventNotFoundException {
		EventResponseSO eventResponseSO = null;

		// Get service id from the claims
		String serviceId = null;
		Object claim = eislClaimsContextUtil.getContextParam("serviceId");
		if (claim != null) {
			serviceId = (String) eislClaimsContextUtil.getContextParam("serviceId");
		}
		log.debug("serviceId from claims:{}", serviceId);
		if (StringUtils.isEmpty(serviceId)) {
			throw new EventBadRequestException(SERVICE_ID_EMPTY_MSG);
		}

		try {
			eventResponseSO = eventDelegate.getEventDetails(serviceId);
			if (eventResponseSO == null) {
				throw new EventNotFoundException(EVENT_NOT_FOUND_MSG + ":" + serviceId);
			}

		} catch (EventException eventException) {
			log.error(eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}

	@RequestMapping(value = "/eisl/event/v1/event", method = RequestMethod.POST)
	public ResponseEntity<EventResponseSO> saveEventDetails(@RequestBody EventRequestSO eventRequestSO)
			throws EventException {
		log.debug("eventRequestSO:{}", eventRequestSO);
		EventResponseSO eventResponseSO = null;

		try {
			eventResponseSO = eventDelegate.saveEventDetails(eventRequestSO);

		} catch (EventException eventException) {
			log.error(eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("eventResponseSO:{}", eventResponseSO);
		return ResponseEntity.ok(eventResponseSO);
	}
}
