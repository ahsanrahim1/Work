package com.ubs.wmap.eisl.ms.eventregistry.util;

import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.ms.eventregistry.context.EislClaimsContext;
import com.ubs.wmap.eisl.ms.eventregistry.context.EislClaimsContextHolder;

import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EislClaimsContextUtil {
	
	public Object getContextParam(String param) {
		log.debug("getContextParam-param:",param);
		EislClaimsContext eislClaimsContext=EislClaimsContextHolder.get();
		if(eislClaimsContext==null) {
			log.debug("eislClaimsContext object is null");
			return null;
		}
		Claims claims=eislClaimsContext.getClaims();
		if(claims==null) {
			log.debug("claims object is null");
			return null;	
		}
		
		return claims.get(param);
	}
	
	public Claims getClaims() {
		EislClaimsContext eislClaimsContext=EislClaimsContextHolder.get();
		if(eislClaimsContext==null) {
			log.debug("eislClaimsContext object is null");
			return null;
		}
		
		Claims claims=eislClaimsContext.getClaims();
		if(claims==null) {
			log.debug("claims object is null");
			return null;	
		}
		
		return claims;
	}

}
