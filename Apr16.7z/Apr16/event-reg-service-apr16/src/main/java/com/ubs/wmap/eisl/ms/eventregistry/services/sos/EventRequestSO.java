package com.ubs.wmap.eisl.ms.eventregistry.services.sos;

import java.io.Serializable;

import lombok.Data;

@Data
public class EventRequestSO implements Serializable{
	
	private static final long serialVersionUID = -998787659770475488L;
	
	private String serviceId;
	private String serviceName;
	private String eventTopic;
	private Integer dataServiceId;
	private Integer exceptionServiceId;

	@Override
    public String toString() {
		 return  "serviceId:"+serviceId
		            + " ,serviceName:"+serviceName
		            +" ,eventTopic:"+eventTopic
		            +" ,dataServiceId:"+(dataServiceId)
		            +" ,exceptionServiceId:"+exceptionServiceId;
    }
	
}
