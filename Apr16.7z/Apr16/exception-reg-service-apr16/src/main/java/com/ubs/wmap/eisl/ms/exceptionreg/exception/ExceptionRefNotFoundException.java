package com.ubs.wmap.eisl.ms.exceptionreg.exception;

public class ExceptionRefNotFoundException extends Exception{
	
	private static final long serialVersionUID = -7408420202454263359L;

	public ExceptionRefNotFoundException(String message) {
		super(message);
	}

}
