package com.ubs.wmap.eisl.ms.exceptionreg.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;

@Data
@Entity
@Table(name = "EXCEPTION_REFERENCE")
@EntityListeners(AuditingEntityListener.class)
public class ExceptionReference implements Serializable {

	private static final long serialVersionUID = -2960973719692214842L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "EXCEPTION_REF_ID")
	private Long exceptionRefId;
	
	@Column(name = "EXCEPTION_SERVICE_ID")
	private Integer exceptionServiceId;
	
	@Column(name = "EXCEPTION_TOPIC")
	private String exceptionTopic;

	@Column(name = "CATEGORY")
	private String category;

	@Column(name = "SEVERITY")
	private String severity;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATION_DATE" , nullable = false, updatable = false)
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	@Column(name = "LAST_UPDATED_DATE")
	private Date lastUpdatedDate;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn (name="EXCEPTION_DATA_REF_ID", unique = true, insertable=true, updatable=true)
	private ExceptionData exceptionData;

}
