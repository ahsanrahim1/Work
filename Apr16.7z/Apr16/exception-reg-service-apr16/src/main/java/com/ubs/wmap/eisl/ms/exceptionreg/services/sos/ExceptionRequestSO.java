package com.ubs.wmap.eisl.ms.exceptionreg.services.sos;

import java.io.Serializable;

import lombok.Data;

@Data
public class ExceptionRequestSO implements Serializable {

	private static final long serialVersionUID = -998787659770475488L;

	private Long exceptionRefId;
	private Integer exceptionServiceId;
	private Long exceptionDataRefId;
	private String category;
	private String severity;
	private String exceptionTopic;

	private ExceptionDataRequestSO exceptionDataRequestSO;
	
	@Override
	public String toString() {
		return  "exceptionServiceId:"+exceptionServiceId
				+" ,exceptionRefId:"+exceptionRefId
				+" ,exceptionDataRefId:" + exceptionDataRefId
				+" ,severity:"+ severity
				+" ,category:"+ category
				+" ,exceptionTopic:" + exceptionTopic;

	}

}
