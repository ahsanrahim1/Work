package com.ubs.wmap.eisl.ms.exceptionreg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.ms.exceptionreg.model.ExceptionData;

@Repository
public interface ExceptionDataRepository extends JpaRepository<ExceptionData, Long> {

}
