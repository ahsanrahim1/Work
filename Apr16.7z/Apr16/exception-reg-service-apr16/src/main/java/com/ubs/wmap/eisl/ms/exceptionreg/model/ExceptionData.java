package com.ubs.wmap.eisl.ms.exceptionreg.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;

@Data
@Entity
@Table(name = "EXCEPTION_DATA")
@EntityListeners(AuditingEntityListener.class)
public class ExceptionData implements Serializable {

	private static final long serialVersionUID = -2960973719692214842L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EXCEPTION_DATA_ID")
	private Long exceptionDataId;

	@Lob
	@Column(name = "STACK_TRACE")
	private String stackTrace;

	@Column(name = "META_DATA")
	private String metadata;
	
	@Column(name = "NONE")
	private String none;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	@Column(name = "CREATION_DATE")
	private Date createdDate;

	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	@Column(name = "LAST_UPDATED_DATE")
	private Date lastUpdatedDate;

}
