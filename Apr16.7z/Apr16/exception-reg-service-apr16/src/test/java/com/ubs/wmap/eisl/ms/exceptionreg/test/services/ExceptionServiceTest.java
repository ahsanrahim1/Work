package com.ubs.wmap.eisl.ms.exceptionreg.test.services;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.ms.exceptionreg.services.ExceptionService;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionResponseSO;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.ms.exceptionreg" })
public class ExceptionServiceTest {
	
	@Autowired
	private ExceptionService exceptionService;
	
	@Test
	public void testGetExceptionDetailsWithData() throws Exception {
		ExceptionRequestSO eventRequestSO=new ExceptionRequestSO();
		eventRequestSO.setExceptionServiceId(Integer.valueOf(1));
		ExceptionResponseSO eventResponseSO = exceptionService.getExceptionDetails(eventRequestSO);
		assertNotNull(eventResponseSO);
	}
	
	@Test
	public void testGetExceptionDetailsWithOutData() throws Exception {
		ExceptionRequestSO eventRequestSO=new ExceptionRequestSO();
		eventRequestSO.setExceptionServiceId(Integer.valueOf(13));
		ExceptionResponseSO eventResponseSO = exceptionService.getExceptionDetails(eventRequestSO);
		assertNull(eventResponseSO);
	}
	
	
	@Test
	public void testSaveExceptionDetails() throws Exception {
	
		ExceptionRequestSO exceptionRequestSO = new ExceptionRequestSO();
		exceptionRequestSO.setCategory("category");
		exceptionRequestSO.setSeverity("severity");
		exceptionRequestSO.setExceptionTopic("topic");
		exceptionRequestSO.setExceptionDataRefId(Long.valueOf("1"));
		ExceptionResponseSO responseSO= exceptionService.saveExceptionDetails(exceptionRequestSO);
		assertNotNull(responseSO);

	}
}
