package com.ubs.wmap.eisl.dataserviceregistry.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "DATA_REFERENCE")
public class DataReference implements Serializable{

	private static final long serialVersionUID = 8682370259634234471L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Data_reference_id")
	private Integer dataReferenceId;
	
	@Column(name = "Data_service_id")
	private String dataServiceId;
	
	@Column(name = "Data_in_topic")
	private String dataInTopic;
	
	@OneToMany(mappedBy="dataOutReference", cascade=CascadeType.ALL)
	private Set<DataOutReference> dataOutReferences;
	
	
}
