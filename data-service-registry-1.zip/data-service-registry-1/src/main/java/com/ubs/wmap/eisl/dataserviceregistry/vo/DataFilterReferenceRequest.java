package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class DataFilterReferenceRequest implements Serializable{
	
	private static final long serialVersionUID = -3472612466681432828L;
	
	private Integer filterRefernceId;
	private String name;
	private String options;
	
}
