package com.ubs.wmap.eisl.dataserviceregistry.exception;

public class DataReferenceNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -7565018735755743641L;
	
	public DataReferenceNotFoundException(String message) {
		super(message);
	}
	public DataReferenceNotFoundException(Throwable cause) {
		super(cause);
	}
	public DataReferenceNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
