package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;


public class DataFilterReference implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -715389885855316908L;
	
	
	private Integer filterRefernceId;
	

	private DataOutReference dataOutReference;
	

	private String filterName;
	

	private String filterOption;

	public Integer getFilterRefernceId() {
		return filterRefernceId;
	}

	public void setFilterRefernceId(Integer filterRefernceId) {
		this.filterRefernceId = filterRefernceId;
	}

	public DataOutReference getDataOutReference() {
		return dataOutReference;
	}

	public void setDataOutReference(DataOutReference dataOutReference) {
		this.dataOutReference = dataOutReference;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getFilterOption() {
		return filterOption;
	}

	public void setFilterOption(String filterOption) {
		this.filterOption = filterOption;
	}
}
