package com.ubs.wmap.eisl.registrationService.DTO;

import lombok.Data;

@Data
public class ExceptionDTO {

	private String exceptionServiceId;
	private String exceptionDataRef;
	private String exceptionTopic;
	private String category;
	private String severity;
}
