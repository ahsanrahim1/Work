package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class EventResponseSO implements Serializable{
	
	private static final long serialVersionUID = 7273465233846581680L;
	
	private String serviceId;
	private String serviceName;
	private String eventTopic;
	private Integer dataServiceId;
	private Integer exceptionServiceId;
	private String createdBy;
	private String lastUpdatedBy;
	private Date createdDate;
	private Date lastUpdatedDate;
	private Long eventServiceId;

	
	@Override
    public String toString() {
        return new StringBuilder("serviceId:").append(serviceId)
            .append(",serviceName:").append(serviceName)
            .append(",eventTopic:").append(eventTopic)
            .append(",dataServiceId:").append(dataServiceId)
            .append(",exceptionServiceId:").append(exceptionServiceId)
            .append(",createdBy:").append(createdBy)
            .append(",lastUpdatedBy:").append(lastUpdatedBy)
            .append(",createdDate:").append(createdDate)
            .append(",lastUpdatedDate:").append(lastUpdatedDate).toString();
    }

}
