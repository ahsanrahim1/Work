package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;
import java.util.Set;

public class DataReference implements Serializable{

	private static final long serialVersionUID = 8682370259634234471L;
	

	private Integer dataReferenceId;
	

	private Integer dataServiceId;
	

	private String dataInTopic;
	

	private String dataOutReference;
	

	private Set<DataOutReference> dataOutReferences;
	
	public Integer getDataReferenceId() {
		return dataReferenceId;
	}

	public void setDataReferenceId(Integer dataReferenceId) {
		this.dataReferenceId = dataReferenceId;
	}

	public Integer getDataServiceId() {
		return dataServiceId;
	}

	public void setDataServiceId(Integer dataServiceId) {
		this.dataServiceId = dataServiceId;
	}

	public String getDataInTopi() {
		return dataInTopic;
	}

	public void setDataInTopi(String dataInTopi) {
		this.dataInTopic = dataInTopi;
	}

	public String getDataOutReference() {
		return dataOutReference;
	}

	public void setDataOutReference(String dataOutReference) {
		this.dataOutReference = dataOutReference;
	}

	public Set<DataOutReference> getDataOutReferences() {
		return dataOutReferences;
	}

	public void setDataOutReferences(Set<DataOutReference> dataOutReferences) {
		this.dataOutReferences = dataOutReferences;
	}
	
}
