package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;

public class DataFilterResponse implements Serializable{

	private static final long serialVersionUID = 228694173931964139L;
	
	private Integer filterRefernceId;
	private String filterName;
	private String filterOption;
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public Integer getFilterRefernceId() {
		return filterRefernceId;
	}
	public void setFilterRefernceId(Integer filterRefernceId) {
		this.filterRefernceId = filterRefernceId;
	}
	public String getFilterOption() {
		return filterOption;
	}
	public void setFilterOption(String filterOption) {
		this.filterOption = filterOption;
	}
	
}
