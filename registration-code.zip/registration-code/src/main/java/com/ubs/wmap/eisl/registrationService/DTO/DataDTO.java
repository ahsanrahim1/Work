package com.ubs.wmap.eisl.registrationService.DTO;

import lombok.Data;

@Data
public class DataDTO {

	private String dataServiceId;
	private String dataInTopic;
	private String dataOutTopic;
}
