package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;


public class DataOutReference implements Serializable{

	
	private static final long serialVersionUID = 6524059507619584069L;
	
	private Integer dataOutReferenceId;
	
	private DataReference dataOutReference;

	private DataFilterReference dataFilterReference;
	
	
	private String protocolName;
	
	
	private String dataType;
	

	private String topicName;
	
	public Integer getDataOutReferenceId() {
		return dataOutReferenceId;
	}

	public void setDataOutReferenceId(Integer dataOutReferenceId) {
		this.dataOutReferenceId = dataOutReferenceId;
	}

	public DataReference getDataOutReference() {
		return dataOutReference;
	}

	public void setDataOutReference(DataReference dataOutReference) {
		this.dataOutReference = dataOutReference;
	}

	public DataFilterReference getDataFilterReference() {
		return dataFilterReference;
	}

	public void setDataFilterReference(DataFilterReference dataFilterReference) {
		this.dataFilterReference = dataFilterReference;
	}

	public String getProtocolName() {
		return protocolName;
	}

	public void setProtocolName(String protocolName) {
		this.protocolName = protocolName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}
}
