package com.ubs.wmap.eisl.registrationService.DTO;

public class RegistrationDTO {

}
