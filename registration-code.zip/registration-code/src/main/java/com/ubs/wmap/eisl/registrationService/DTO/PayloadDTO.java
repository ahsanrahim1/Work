package com.ubs.wmap.eisl.registrationService.DTO;

import lombok.Data;

@Data
public class PayloadDTO {
    private String userName;
    private String company;
}
