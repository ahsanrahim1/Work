package com.ubs.wmap.eisl.registrationService.model;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class ResponseSO {
	

	private Map<String,Object> Response = new HashMap<>();
	
	
	
	
	
	
}

