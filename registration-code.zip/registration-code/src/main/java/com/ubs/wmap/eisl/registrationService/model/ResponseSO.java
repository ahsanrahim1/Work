package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

@Data
public class ResponseSO {
	
	
	private EventResponseSO eventDto;
	private DataSO dataDto;
	private ExceptionResponseSO exceptionDto;
	private RegistrationSO registrationDto;
	

	
	
	
	
}

