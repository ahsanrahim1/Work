package com.ubs.wmap.eisl.registrationService.service;

import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.DATA_END_POINT;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.EVENTS_END_POINT;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.EXCEPTIONS_END_POINT;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.REGISTRY_ACCESS_END_POINT;


import java.util.Map;

import javax.validation.constraints.NotBlank;

//import com.ubs.wmap.eisl.housekeeping.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.ubs.wmap.eisl.registrationService.DTO.DataDTO;
import com.ubs.wmap.eisl.registrationService.DTO.EventDTO;
import com.ubs.wmap.eisl.registrationService.DTO.ExceptionDTO;
import com.ubs.wmap.eisl.registrationService.DTO.PayloadDTO;
import com.ubs.wmap.eisl.registrationService.DTO.RegistrationDTO;
import com.ubs.wmap.eisl.registrationService.DTO.ResponseDTO;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;

import io.jsonwebtoken.Claims;


@Service
public class RegistrationServiceImpl {
	
	

	  
	  @Autowired
	  private RestTemplate restTemplate;
	 // private TokenService tokenService;

	

    public boolean validateToken(String basicToken, String eislToken, Map<String,String> claims) {
    	 boolean isValid = false;
    	try {
         // isValid = tokenService.isEISLTokenValid(eislToken);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return isValid;
        
    }
    public ResponseEntity<RegistrationDTO>  getRegistryResponse(String baseUrl,String firstParam,String stringParam,PayloadDTO payload) {
    	   
        final String url = String.format("/eisl/%s", baseUrl);
       
        HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", firstParam);
    	
    	 MultiValueMap<String, PayloadDTO> map= new LinkedMultiValueMap<String, PayloadDTO>();
         map.add("payload", payload);
         
             	
    	HttpEntity< MultiValueMap<String, PayloadDTO>> requestEntity = new HttpEntity<>(map,headers);
    	
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken", stringParam);
        
        final ResponseEntity<RegistrationDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, requestEntity,
                        new ParameterizedTypeReference<RegistrationDTO>() {});
        return responseDto;
      }
    
    public ResponseEntity<RegistrationDTO>  postRegistryResponse(String baseUrl, RegistrationDTO registrationData) {
 	   
        final String url = String.format("/eisl/%s", baseUrl);
        
        
        
        MultiValueMap<String, RegistrationDTO> map= new LinkedMultiValueMap<String, RegistrationDTO>();
        map.add("payload", registrationData);
        
        HttpEntity< MultiValueMap<String, RegistrationDTO>> requestEntity = new HttpEntity<>(map);
        	
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("registrationData", registrationData);
        
        final ResponseEntity<RegistrationDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.POST, requestEntity,
                        new ParameterizedTypeReference<RegistrationDTO>() {});
        return responseDto;
      }
    
    public ResponseEntity<RegistrationDTO>  putRegistryResponse(String baseUrl, RegistrationDTO registrationData) {
  	   
        final String url = String.format("/eisl/%s", baseUrl);
       
   

    	
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("registrationData", registrationData);
        
        final ResponseEntity<RegistrationDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.PUT, null,
                        new ParameterizedTypeReference<RegistrationDTO>() {});
        return responseDto;
      }
    
    public ResponseEntity<EventDTO>  getEventsResponse(String baseUrl,String firstParam,String stringParam) {
   
        final String url = String.format("/eisl/%s", baseUrl);
       
        HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", firstParam);
    	
    	HttpEntity<EventDTO> requestEntity = new HttpEntity<>(headers);
    	
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken", stringParam);
        
        final ResponseEntity<EventDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, requestEntity,
                        new ParameterizedTypeReference<EventDTO>() {});
        return responseDto;
      }
    
    public ResponseEntity<DataDTO>  getDataResponse(String baseUrl,String firstParam,String stringParam,String basicToken) {
    	   
        final String url = String.format("/eisl/%s", baseUrl);
        HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", basicToken);
    	
    	HttpEntity<DataDTO> requestEntity = new HttpEntity<>(headers);
       
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken",firstParam )
                .queryParam("dataServiceId", stringParam);
        
        final ResponseEntity<DataDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, requestEntity,
                        new ParameterizedTypeReference<DataDTO>() {});
        return responseDto;
      }
    
    public ResponseEntity<ExceptionDTO>  getExceptionsResponse(String baseUrl,String firstParam,String stringParam,String basicToken) {
    	   
        final String url = String.format("/eisl/%s", baseUrl);
        HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", basicToken);
    	
    	HttpEntity<ExceptionDTO> requestEntity = new HttpEntity<>(headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken",firstParam )
                .queryParam("exceptionServiceId", stringParam);
        final ResponseEntity<ExceptionDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, requestEntity,
                        new ParameterizedTypeReference<ExceptionDTO>() {});
        return responseDto;
        
      }

    
    public ResponseDTO deleteRegistration( String baseUrl, String basicToken,String eislToken)
    {
    	final String url = String.format("/eisl/%s", baseUrl);
    	
    	HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", basicToken);
    	
    	HttpEntity<ResponseDTO> requestEntity = new HttpEntity<>(headers);
    	
    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
    			.queryParam("basicToken",basicToken )
                .queryParam("eislToken", eislToken);
    	
    	final ResponseEntity<ResponseDTO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE, requestEntity,
                new ParameterizedTypeReference<ResponseDTO>() {});
    	return responseDto.getBody();
    }
    
    public ResponseDTO postRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadDTO payload) throws InvalidDataException {

		ResponseDTO responseDTO = new ResponseDTO();
		ResponseEntity<RegistrationDTO> getResponse = getRegistryResponse(EVENTS_END_POINT, basicToken, eislToken,payload);
		if(getResponse.getStatusCode()==HttpStatus.OK)
		{
			responseDTO.setRegistrationDto(getResponse.getBody());
			return responseDTO;
		}
		ResponseEntity<EventDTO> eventsResponse = getEventsResponse(EVENTS_END_POINT, basicToken, eislToken);
		ResponseEntity<DataDTO> dataResponse = getDataResponse(DATA_END_POINT, eislToken, eventsResponse.getBody().getDataServiceId().toString(),basicToken);
		ResponseEntity<ExceptionDTO> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, eislToken, eventsResponse.getBody().getExceptionServiceId(),basicToken);
		if(eventsResponse.getStatusCode()==HttpStatus.BAD_REQUEST || dataResponse.getStatusCode()==HttpStatus.BAD_REQUEST || exceptionResponse.getStatusCode()==HttpStatus.BAD_REQUEST) {
			throw new InvalidDataException();
		}
		RegistrationDTO builtRegistry = buildRegistration(payload, eislToken);
		ResponseEntity<RegistrationDTO> postResponse = postRegistryResponse(REGISTRY_ACCESS_END_POINT, builtRegistry);
		responseDTO.setRegistrationDto(postResponse.getBody());
		return responseDTO;
	}
    
    public ResponseDTO putRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadDTO payload) throws InvalidDataException {

		ResponseDTO responseDTO = new ResponseDTO();
		ResponseEntity<RegistrationDTO> getResponse = getRegistryResponse(EVENTS_END_POINT, basicToken, eislToken,payload);
		if(getResponse.getStatusCode()==HttpStatus.OK)
		{
			responseDTO.setRegistrationDto(getResponse.getBody());
			return responseDTO;
		}
		ResponseEntity<EventDTO> eventsResponse = getEventsResponse(EVENTS_END_POINT, basicToken, eislToken);
		ResponseEntity<DataDTO> dataResponse = getDataResponse(DATA_END_POINT, eislToken, eventsResponse.getBody().getDataServiceId().toString(),basicToken);
		ResponseEntity<ExceptionDTO> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, eislToken, eventsResponse.getBody().getExceptionServiceId(),basicToken);
		if(eventsResponse.getStatusCode()==HttpStatus.BAD_REQUEST || dataResponse.getStatusCode()==HttpStatus.BAD_REQUEST || exceptionResponse.getStatusCode()==HttpStatus.BAD_REQUEST) {
			throw new InvalidDataException();
		}
		RegistrationDTO builtRegistry = buildRegistration(payload, eislToken);
		ResponseEntity<RegistrationDTO> putResponse = putRegistryResponse(REGISTRY_ACCESS_END_POINT, builtRegistry);
		responseDTO.setRegistrationDto(putResponse.getBody());
		return responseDTO;
	}
    
    public RegistrationDTO buildRegistration(PayloadDTO payload,String eislToken) {
    	// add library and extract token here
        Claims claims = null;
        RegistrationDTO builtRegistration = RegistrationDTO.builder().userName(payload.getUserName())
        		                            .company(payload.getCompany()).columnRef(claims.get("columnRef")
        		                            .toString()).eislToken(eislToken).serviceId(claims.get("serviceId")
        		                            .toString()).userId(claims.get("columnRef").toString()).rowRef(claims.get("rowRef").toString())
        		                            .build();
        builtRegistration.setDataEntitlement("Not Clear about the DATA yet");
        		
    	return builtRegistration;
    }

	public ResponseDTO getRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadDTO payload) throws InvalidDataException {

		ResponseDTO responseDTO = new ResponseDTO();
		ResponseEntity<RegistrationDTO> getResponse = getRegistryResponse(EVENTS_END_POINT, basicToken, eislToken,payload);
		if(getResponse.getStatusCode()==HttpStatus.OK)
		{
			responseDTO.setRegistrationDto(getResponse.getBody());
			return responseDTO;
		}
		ResponseEntity<EventDTO> eventsResponse = getEventsResponse(EVENTS_END_POINT, basicToken, eislToken);
		ResponseEntity<DataDTO> dataResponse = getDataResponse(DATA_END_POINT, eislToken, eventsResponse.getBody().getDataServiceId().toString(),basicToken);
		ResponseEntity<ExceptionDTO> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, eislToken, eventsResponse.getBody().getExceptionServiceId(),basicToken);
		if(eventsResponse.getStatusCode()==HttpStatus.BAD_REQUEST || dataResponse.getStatusCode()==HttpStatus.BAD_REQUEST || exceptionResponse.getStatusCode()==HttpStatus.BAD_REQUEST) {
			throw new InvalidDataException();
		}
		responseDTO.setEventDto(eventsResponse.getBody());
		responseDTO.setDataDto(dataResponse.getBody());
		responseDTO.setExceptionDto(exceptionResponse.getBody());
		return responseDTO;
	}
}
