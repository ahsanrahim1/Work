package com.ubs.wmap.eisl.registrationService.service;

import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.DATA_END_POINT;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.EVENTS_END_POINT;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.EXCEPTIONS_END_POINT;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotBlank;

//import com.ubs.wmap.eisl.housekeeping.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.ubs.wmap.eisl.registrationService.DTO.DataDTO;
import com.ubs.wmap.eisl.registrationService.DTO.EventDTO;
import com.ubs.wmap.eisl.registrationService.DTO.ExceptionDTO;
import com.ubs.wmap.eisl.registrationService.DTO.RegistrationDTO;
import com.ubs.wmap.eisl.registrationService.DTO.ResponseDTO;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;


@Service
public class RegistrationServiceImpl {
	
	

	  
	  @Autowired
	  private RestTemplate restTemplate;
	 // private TokenService tokenService;

	

    public boolean validateToken(String basicToken, String eislToken, Map<String,String> claims) {
    	 boolean isValid = false;
    	try {
         // isValid = tokenService.isEISLTokenValid(eislToken);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return isValid;
        
    }
    public ResponseEntity<RegistrationDTO>  getRegistryResponse(String baseUrl,String firstParam,String stringParam) {
    	   
        final String url = String.format("/eisl/%s", baseUrl);
       
        HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", firstParam);
    	
    	HttpEntity<RegistrationDTO> requestEntity = new HttpEntity<>(headers);
    	
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken", stringParam);
        
        final ResponseEntity<RegistrationDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, requestEntity,
                        new ParameterizedTypeReference<RegistrationDTO>() {});
        return responseDto;
      }
    
    public ResponseEntity<EventDTO>  getEventsResponse(String baseUrl,String firstParam,String stringParam) {
   
        final String url = String.format("/eisl/%s", baseUrl);
       
        HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", firstParam);
    	
    	HttpEntity<EventDTO> requestEntity = new HttpEntity<>(headers);
    	
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken", stringParam);
        
        final ResponseEntity<EventDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, requestEntity,
                        new ParameterizedTypeReference<EventDTO>() {});
        return responseDto;
      }
    
    public ResponseEntity<DataDTO>  getDataResponse(String baseUrl,String firstParam,String stringParam,String basicToken) {
    	   
        final String url = String.format("/eisl/%s", baseUrl);
        HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", basicToken);
    	
    	HttpEntity<DataDTO> requestEntity = new HttpEntity<>(headers);
       
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken",firstParam )
                .queryParam("dataServiceId", stringParam);
        
        final ResponseEntity<DataDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, requestEntity,
                        new ParameterizedTypeReference<DataDTO>() {});
        return responseDto;
      }
    
    public ResponseEntity<ExceptionDTO>  getExceptionsResponse(String baseUrl,String firstParam,String stringParam,String basicToken) {
    	   
        final String url = String.format("/eisl/%s", baseUrl);
        HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", basicToken);
    	
    	HttpEntity<ExceptionDTO> requestEntity = new HttpEntity<>(headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("eislToken",firstParam )
                .queryParam("exceptionServiceId", stringParam);
        final ResponseEntity<ExceptionDTO> responseDto =
        		restTemplate.exchange(builder.toUriString(), HttpMethod.GET, requestEntity,
                        new ParameterizedTypeReference<ExceptionDTO>() {});
        return responseDto;
        
      }

    
    public ResponseDTO deleteRegistration( String baseUrl, String basicToken,String eislToken)
    {
    	final String url = String.format("/eisl/%s", baseUrl);
    	
    	HttpHeaders headers = new HttpHeaders();
    	headers.add("basicToken", basicToken);
    	
    	HttpEntity<ResponseDTO> requestEntity = new HttpEntity<>(headers);
    	
    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
    			.queryParam("basicToken",basicToken )
                .queryParam("eislToken", eislToken);
    	
    	final ResponseEntity<ResponseDTO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE, requestEntity,
                new ParameterizedTypeReference<ResponseDTO>() {});
    	return responseDto.getBody();
    }

	public ResponseDTO getRegistration(@NotBlank String basicToken, @NotBlank String eislToken) {

		ResponseDTO responseDTO = new ResponseDTO();
		ResponseEntity<RegistrationDTO> getResponse = getRegistryResponse(EVENTS_END_POINT, basicToken, eislToken);
		if(getResponse.getStatusCode()==HttpStatus.OK)
		{
			responseDTO.setRegistrationDto(getResponse.getBody());
			return responseDTO;
		}
		ResponseEntity<EventDTO> eventsResponse = getEventsResponse(EVENTS_END_POINT, basicToken, eislToken);
		ResponseEntity<DataDTO> dataResponse = getDataResponse(DATA_END_POINT, eislToken, eventsResponse.getBody().getDataServiceId().toString(),basicToken);
		ResponseEntity<ExceptionDTO> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, eislToken, eventsResponse.getBody().getExceptionServiceId(),basicToken);
		if(eventsResponse == null || dataResponse == null || exceptionResponse == null) {
			throw new InvalidDataException();
		}
		responseDTO.setEventDto(eventsResponse.getBody());
		return responseDTO;
	}
}
