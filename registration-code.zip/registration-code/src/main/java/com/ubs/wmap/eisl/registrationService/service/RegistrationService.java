package com.ubs.wmap.eisl.registrationService.service;

import javax.validation.constraints.NotBlank;

import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;


public interface RegistrationService {

	boolean validateToken(String basicToken, String eislToken) throws Exception;
	ResponseSO getRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadSO payload) throws InvalidDataException;
	RegistrationSO putRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadSO payload) throws InvalidDataException;
	RegistrationSO postRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadSO payload) throws InvalidDataException;
	ResponseSO deleteRegistration( String baseUrl, String basicToken,String eislToken);
}
