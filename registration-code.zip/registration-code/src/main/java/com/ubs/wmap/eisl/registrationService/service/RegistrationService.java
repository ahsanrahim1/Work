package com.ubs.wmap.eisl.registrationService.service;

import java.util.Map;

import javax.validation.constraints.NotBlank;

import com.ubs.wmap.eisl.registrationService.DTO.PayloadDTO;
import com.ubs.wmap.eisl.registrationService.DTO.ResponseDTO;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;

public interface RegistrationService {

	boolean validateToken(String basicToken, String eislToken, Map<String,String> claims);
	ResponseDTO getRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadDTO payload) throws InvalidDataException;
	ResponseDTO putRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadDTO payload) throws InvalidDataException;
	ResponseDTO postRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadDTO payload) throws InvalidDataException;
	ResponseDTO deleteRegistration( String baseUrl, String basicToken,String eislToken);
}
