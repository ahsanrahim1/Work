package com.ubs.wmap.eisl.registrationService.DTO;

import lombok.Data;

@Data
public class ResponseDTO {
	
	
	private EventDTO eventDto;
	private DataDTO dataDto;
	private ExceptionDTO exceptionDto;
	private RegistrationDTO registrationDto;
	

	
	
	
	
}

