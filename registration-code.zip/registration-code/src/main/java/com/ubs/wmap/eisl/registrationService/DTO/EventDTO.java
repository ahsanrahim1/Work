package com.ubs.wmap.eisl.registrationService.DTO;

import lombok.Data;

@Data
public class EventDTO {

	private String serviceId;
	private String parameters;
	private String eventTopic;
	private String dataServiceId;
	private String ExceptionServiceId;
	private String serviceUrl;
}
