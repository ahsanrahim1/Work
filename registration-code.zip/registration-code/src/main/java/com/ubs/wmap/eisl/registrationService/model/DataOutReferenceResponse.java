package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;

public class DataOutReferenceResponse implements Serializable {

	private static final long serialVersionUID = 8023385196692316336L;
	private Integer dataOutReferenceId;
	private String protocolName;
	private String dataType;
	private String topicName;
	private DataFilterResponse dataFilterReference;
	public Integer getDataOutReferenceId() {
		return dataOutReferenceId;
	}
	public void setDataOutReferenceId(Integer dataOutReferenceId) {
		this.dataOutReferenceId = dataOutReferenceId;
	}
	public String getProtocalName() {
		return protocolName;
	}
	public void setProtocalName(String protocalName) {
		this.protocolName = protocalName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getTopicName() {
		return topicName;
	}
	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}
	public DataFilterResponse getDataFilterReference() {
		return dataFilterReference;
	}
	public void setDataFilterReference(DataFilterResponse dataFilterReference) {
		this.dataFilterReference = dataFilterReference;
	}
}
