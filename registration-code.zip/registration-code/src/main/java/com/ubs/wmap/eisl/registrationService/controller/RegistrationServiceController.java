package com.ubs.wmap.eisl.registrationService.controller;


import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.REGISTRATION_END_POINT;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.registrationService.DTO.PayloadDTO;
import com.ubs.wmap.eisl.registrationService.DTO.ResponseDTO;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping(value = "/eisl/registration/v1", produces = "application/json")
public class RegistrationServiceController {
	
	
	@Autowired
	private RegistrationServiceImpl registrationService;
	
	
	@RequestMapping(value = REGISTRATION_END_POINT, method= RequestMethod.GET)
    public ResponseEntity<ResponseDTO> getRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                           @NotBlank @RequestParam final String eislToken,@RequestBody PayloadDTO payload) {
		boolean valid = registrationService.validateToken(basicToken, eislToken, null);	
    	if(!valid)
    	{
    		log.error("Eisl Token not valid");
    		return ResponseEntity.badRequest().body(null);
    	}
    	ResponseDTO dto;
		try {
			dto = registrationService.getRegistration(basicToken, eislToken,payload);
			 return ResponseEntity.ok()
		                .body(dto);
		} catch (InvalidDataException e) {
			 return ResponseEntity.badRequest().body(null);
		}    	
    }

    @RequestMapping(value = REGISTRATION_END_POINT, method= RequestMethod.POST)
    public ResponseEntity<ResponseDTO> addRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                              @NotBlank @RequestParam final String eislToken,@RequestBody PayloadDTO payload) {
    	
    	boolean valid = registrationService.validateToken(basicToken, eislToken, null);	
    	if(!valid)
    	{
    		log.error("Eisl Token not valid");
    		return ResponseEntity.badRequest().body(null);
    	}  	
    	ResponseDTO dto;
		try {
			dto = registrationService.getRegistration(basicToken, eislToken,payload);
			return ResponseEntity.ok()
	                .body(dto);
		} catch (InvalidDataException e) {
			// TODO Auto-generated catch block
			return ResponseEntity.badRequest().body(null);
		}    	
        
    }
    
    @RequestMapping(value = REGISTRATION_END_POINT, method= RequestMethod.PUT)
    public ResponseEntity<Object> updateRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                              @NotBlank @RequestParam final String eislToken,@RequestBody PayloadDTO payload) {
    	boolean valid = registrationService.validateToken(basicToken, eislToken, null);	
    	if(!valid)
    	{
    		log.error("Eisl Token not valid");
    		return ResponseEntity.badRequest().body(null);
    	}  	
    	ResponseDTO dto;
		try {
			dto = registrationService.getRegistration(basicToken, eislToken,payload);
			return ResponseEntity.ok()
	                .body(dto);
		} catch (InvalidDataException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return ResponseEntity.badRequest().body(null);

		}    	
        
    }

    
    
    @RequestMapping(value = REGISTRATION_END_POINT, method= RequestMethod.DELETE)
    public ResponseEntity<Object> deleteRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken, @NotBlank @RequestParam final String eislToken) {
    	boolean valid = registrationService.validateToken(basicToken, eislToken, null);	
    	if(!valid)
    	{
    		log.error("Eisl Token not valid");
    		return ResponseEntity.badRequest().body(null);
    	}
        return ResponseEntity.ok()
                .body(registrationService.deleteRegistration("user/v1/registrations", basicToken, eislToken));
    }
}
