package com.ubs.wmap.eisl.registrationService.controller;


import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.REGISTRATION_END_POINT;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants;
import com.ubs.wmap.eisl.registrationService.exception.EsilTokenNotValidException;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@AllArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@RequestMapping(produces = "application/json")
public class RegistrationServiceController {
	
	
	
	private final RegistrationServiceImpl registrationService;
	
	
	@GetMapping(value = REGISTRATION_END_POINT)
    public ResponseEntity<ResponseSO> getRegistry(@NotBlank @RequestHeader(name = "BasicToken")  String basicToken,
                                           @NotBlank @RequestParam("eislToken")  String eislToken,@RequestParam("companyName") String companyName,@RequestParam("userName") String userName) throws EsilTokenNotValidException, InvalidDataException {
		PayloadSO payload = new PayloadSO();
//		payload.setCompany(companyName);
//	    payload.setUserName(userName);

		boolean valid = registrationService.validateToken(basicToken, eislToken);
		if(!valid)
    	{
    		log.error("Eisl Token not valid");
    		throw new EsilTokenNotValidException(RegistrationConstants.INVALID_ESIL_TOKEN);
    	}
    	ResponseSO dto;
		try {
			dto = registrationService.getRegistration(basicToken, eislToken,payload);
			 return ResponseEntity.ok()
		                .body(dto);
		} catch (InvalidDataException e) {
			log.error("Invalid Data to build registry");
			 throw new InvalidDataException(RegistrationConstants.DATA_NOT_FOUND);
		}    	
    }

    @PostMapping(value = REGISTRATION_END_POINT)
    public ResponseEntity<RegistrationSO> addRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                              @NotBlank @RequestParam final String eislToken,@RequestBody PayloadSO payload) throws EsilTokenNotValidException, InvalidDataException {
    	
    	boolean valid = registrationService.validateToken(basicToken, eislToken);	
    	if(!valid)
    	{
    		log.error("Eisl Token not valid");
    		throw new EsilTokenNotValidException(RegistrationConstants.INVALID_ESIL_TOKEN);
    	}  	
    	RegistrationSO dto;
		try {
			dto = registrationService.postRegistration(basicToken, eislToken,payload);
			return ResponseEntity.ok()
	                .body(dto);
		} catch (InvalidDataException e) {
			log.error("Invalid Data to build registry");
			throw new InvalidDataException(RegistrationConstants.DATA_NOT_FOUND);
		}    	
        
    }
    
    @PutMapping(value = REGISTRATION_END_POINT)
    public ResponseEntity<RegistrationSO> updateRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                              @NotBlank @RequestParam final String eislToken,@RequestBody PayloadSO payload) throws EsilTokenNotValidException, InvalidDataException {
    	boolean valid = registrationService.validateToken(basicToken, eislToken);	
    	if(!valid)
    	{
    		log.error("Eisl Token not valid");
    		throw new EsilTokenNotValidException(RegistrationConstants.INVALID_ESIL_TOKEN);
    	}  	
    	RegistrationSO dto;
		try {
			dto = registrationService.putRegistration(basicToken, eislToken,payload);
			return ResponseEntity.ok()
	                .body(dto);
		} catch (InvalidDataException e) {
			log.error("Invalid Data to build registry");
			throw new InvalidDataException(RegistrationConstants.DATA_NOT_FOUND);
		}    	
        
    }

    
    
    @DeleteMapping(value = REGISTRATION_END_POINT)
    public ResponseEntity<Object> deleteRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken, @NotBlank @RequestParam final String eislToken) throws EsilTokenNotValidException {
    	boolean valid = registrationService.validateToken(basicToken, eislToken);	
    	if(!valid)
    	{
    		log.error("Eisl Token not valid");
    		throw new EsilTokenNotValidException(RegistrationConstants.INVALID_ESIL_TOKEN);
    	}
        return ResponseEntity.ok()
                .body(registrationService.deleteRegistration("user/v1/registrations", basicToken, eislToken));
    }
}
