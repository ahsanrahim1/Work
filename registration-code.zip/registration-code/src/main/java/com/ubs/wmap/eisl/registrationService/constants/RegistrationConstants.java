package com.ubs.wmap.eisl.registrationService.constants;




public class RegistrationConstants {
   
	public static final String INVALID_ESIL_TOKEN = "Invalid Eisl Token";
	public static final String DATA_NOT_FOUND = "Data could not be found";
	
	
//	public static final String REGISTRATION_END_POINT = "/eisl/registrations/v1/registrations";
//	public static final String EVENTS_END_POINT = "event/v1/events";
//	public static final String DATA_END_POINT = "data/v1/data";
//	public static final String EXCEPTIONS_END_POINT = "exception/v1/exceptions";
//	public static final String REGISTRY_ACCESS_END_POINT = "users/v1/registrations";
	
	
	//This is for testing
	public static final String REGISTRATION_END_POINT = "/eisl/registrations/v1/registrations";
	public static final String EVENTS_END_POINT = "http://localhost:8087/eisl/event/v1/events";
	public static final String DATA_END_POINT = "http://localhost:8080/eisl/data/v1/data";
	public static final String EXCEPTIONS_END_POINT = "http://localhost:8085/eisl/exception/v1/exceptions";
	public static final String REGISTRY_ACCESS_END_POINT = "http://localhost:8089/eisl/users/v1/registrations";
			

	
	
}
